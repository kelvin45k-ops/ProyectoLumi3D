package pc2;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

public class RegistroCliente extends JFrame {

    // ─── Conexion ───
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private ChatPanel chatPanel;
    private final BlockingQueue<MensajePC2> colaRespuestas = new LinkedBlockingQueue<MensajePC2>();

    // ─── GUI ───
    private JTextField txtDPI, txtNombre, txtApellido;
    private JRadioButton rbGeneral, rbPrioritaria, rbEspecial;
    private JLabel lblEstado, lblTicketGenerado;
    private JTextArea txtLog;
    private JButton btnRegistrar;
    private JButton btnBuscar;

    // Campos dinamicos (cantidad de lamparas, edad, etc.)
    private JPanel panelDinamico;
    private JSpinner spnCantLampGeneral;     // 1-5
    private JSpinner spnCantLampEspecial;    // >= 15 (mayoreo)
    private JComboBox<String> cbMotivoPrior; // Adulto Mayor / Discapacidad / Embarazada
    private JSpinner spnEdad;
    private JSpinner spnMesesGestacion;

    // ─── Colores tema Lumi 3D ───
    // ──────── PALETA LUMI 3D - TEMA CLARO ────────
    private static final Color BG       = new Color(210, 210, 210);  // gris ceniza
    private static final Color CARD     = new Color(255, 255, 255);  // tarjetas
    private static final Color CARD2    = new Color(238, 238, 238);  // alt
    private static final Color BORDER   = new Color(181, 181, 181);  // bordes
    private static final Color ACCENT   = new Color(201, 162, 39);   // dorado Lumi
    private static final Color ACCENT2  = new Color(168, 130, 30);   // dorado oscuro
    private static final Color OK_GREEN = new Color(95, 170, 95);    // verde
    private static final Color DANGER   = new Color(200, 80, 80);    // rojo
    private static final Color TEXT     = new Color(44, 44, 44);     // texto principal
    private static final Color TEXT_DIM = new Color(102, 102, 102);  // texto secundario

    public RegistroCliente() {
        initGUI();
        conectar();
        setVisible(true);
    }

    // ══════════════════════════ GUI ══════════════════════════════════════
    private void initGUI() {
        setTitle("Lumi 3D  -  PUNTO DE REGISTRO");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(720, 760);
        setMinimumSize(new Dimension(680, 700));
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout(10, 10));

        add(crearHeader(), BorderLayout.NORTH);
        add(crearForm(), BorderLayout.CENTER);
        add(crearFooter(), BorderLayout.SOUTH);
    }

    private JPanel crearHeader() {
        JPanel p = new JPanel(new BorderLayout(15, 0));
        p.setBackground(CARD);
        p.setBorder(new CompoundBorder(
            new MatteBorder(0, 0, 2, 0, ACCENT),
            new EmptyBorder(14, 22, 14, 22)));

        // Lado izquierdo: logo grafico + titulo
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        left.setOpaque(false);
        left.add(new LogoLumi3D(56, false));

        JPanel titulos = new JPanel();
        titulos.setLayout(new BoxLayout(titulos, BoxLayout.Y_AXIS));
        titulos.setOpaque(false);
        JLabel titleMain = new JLabel("Lumi 3D");
        titleMain.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleMain.setForeground(ACCENT);
        JLabel titleSub = new JLabel("Punto de Registro  -  PC2");
        titleSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        titleSub.setForeground(TEXT_DIM);
        titulos.add(titleMain);
        titulos.add(titleSub);
        left.add(titulos);

        // Lado derecho: chat + estado
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);
        lblEstado = new JLabel("DESCONECTADO");
        lblEstado.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblEstado.setForeground(DANGER);

        JButton btnChat = new JButton("CHAT");
        btnChat.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btnChat.setBackground(ACCENT);
        btnChat.setForeground(Color.WHITE);
        btnChat.setBorder(new EmptyBorder(6, 16, 6, 16));
        btnChat.setFocusPainted(false);
        btnChat.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnChat.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (chatPanel != null) chatPanel.setVisible(true);
            }
        });

        right.add(btnChat);
        right.add(lblEstado);

        p.add(left, BorderLayout.WEST);
        p.add(right, BorderLayout.EAST);
        return p;
    }

    private JPanel crearForm() {
        // Panel raiz que envuelve y posiciona el form a la izquierda
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(BG);
        wrapper.setBorder(new EmptyBorder(12, 24, 12, 24));

        // Form efectivo
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(BG);

        // ──────── DATOS DEL CLIENTE ────────
        p.add(seccion("DATOS DEL CLIENTE"));

        // DPI con boton BUSCAR al lado derecho
        txtDPI = inputField("DPI", 13);
        btnBuscar = new JButton("BUSCAR");
        btnBuscar.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.setBackground(ACCENT2);
        btnBuscar.setBorder(new EmptyBorder(8, 16, 8, 16));
        btnBuscar.setFocusPainted(false);
        btnBuscar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnBuscar.setPreferredSize(new Dimension(100, 38));
        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { buscarPorDPI(); }
        });
        // Tambien permitir Enter en el DPI para buscar
        txtDPI.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { buscarPorDPI(); }
        });

        p.add(labeledConBoton("DPI", txtDPI, btnBuscar));

        txtNombre = inputField("Nombre", 30);
        p.add(labeled("NOMBRE", txtNombre));
        txtApellido = inputField("Apellido", 30);
        p.add(labeled("APELLIDO", txtApellido));

        p.add(Box.createVerticalStrut(14));

        // ──────── TIPO DE ATENCION ────────
        p.add(seccion("TIPO DE ATENCION"));
        rbGeneral     = radio("ATENCION GENERAL  (1-14 lamparas)",       true);
        rbPrioritaria = radio("ATENCION PRIORITARIA  (mayores/embarazo/discap.)", false);
        rbEspecial    = radio("VENTAS POR MAYOREO  (15+ lamparas)",      false);
        ButtonGroup grp = new ButtonGroup();
        grp.add(rbGeneral);
        grp.add(rbPrioritaria);
        grp.add(rbEspecial);

        ActionListener cambiarTipo = new ActionListener() {
            public void actionPerformed(ActionEvent e) { actualizarPanelDinamico(); }
        };
        rbGeneral.addActionListener(cambiarTipo);
        rbPrioritaria.addActionListener(cambiarTipo);
        rbEspecial.addActionListener(cambiarTipo);

        p.add(rbGeneral);
        p.add(rbPrioritaria);
        p.add(rbEspecial);

        p.add(Box.createVerticalStrut(10));

        // Panel dinamico segun tipo
        panelDinamico = new JPanel();
        panelDinamico.setLayout(new BoxLayout(panelDinamico, BoxLayout.Y_AXIS));
        panelDinamico.setBackground(BG);
        panelDinamico.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(panelDinamico);

        p.add(Box.createVerticalStrut(18));

        // ──────── BOTON REGISTRAR ────────
        btnRegistrar = new JButton("REGISTRAR Y GENERAR TICKET");
        btnRegistrar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnRegistrar.setForeground(Color.WHITE);
        btnRegistrar.setBackground(ACCENT);
        btnRegistrar.setBorder(new EmptyBorder(12, 0, 12, 0));
        btnRegistrar.setFocusPainted(false);
        btnRegistrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRegistrar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        btnRegistrar.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { registrar(); }
        });
        p.add(btnRegistrar);

        // Inicializar panel dinamico
        actualizarPanelDinamico();

        wrapper.add(p, BorderLayout.NORTH);
        return wrapper;
    }

    /**
     * Igual que labeled() pero con un boton (BUSCAR) a la derecha del input
     */
    private Component labeledConBoton(String label, JComponent input, JComponent boton) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(BG);
        p.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel l = new JLabel(label);
        l.setFont(new Font("Segoe UI", Font.BOLD, 10));
        l.setForeground(TEXT_DIM);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        l.setBorder(new EmptyBorder(4, 0, 2, 0));
        p.add(l);

        // Linea horizontal con input + boton
        JPanel fila = new JPanel(new BorderLayout(8, 0));
        fila.setBackground(BG);
        fila.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        fila.setAlignmentX(Component.LEFT_ALIGNMENT);
        fila.add(input, BorderLayout.CENTER);
        fila.add(boton, BorderLayout.EAST);
        p.add(fila);

        return p;
    }

    /**
     * Busca el DPI en el historial del servidor.
     * Si existe -> ofrece autocompletar nombre y apellido.
     * Si no existe -> avisa que es un DPI nuevo.
     */
    private void buscarPorDPI() {
        final String dpi = txtDPI.getText().trim();
        if (dpi.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Ingresa un DPI para buscar.",
                "Campo vacio", JOptionPane.WARNING_MESSAGE);
            txtDPI.requestFocus();
            return;
        }
        if (dpi.length() < 13) {
            JOptionPane.showMessageDialog(this,
                "El DPI debe tener al menos 13 caracteres.",
                "DPI invalido", JOptionPane.WARNING_MESSAGE);
            txtDPI.requestFocus();
            return;
        }
        if (out == null) {
            JOptionPane.showMessageDialog(this,
                "Sin conexion con el servidor.\n\nEspera a que se reconecte.",
                "Sin conexion", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Enviar busqueda al servidor en un hilo aparte
        new Thread(new Runnable() {
            public void run() {
                try {
                    synchronized (out) {
                        out.println(new MensajePC2(MensajePC2.BUSCAR_DPI, dpi).toWire());
                    }
                    // Esperar respuesta hasta 3 segundos
                    MensajePC2 resp = colaRespuestas.poll(3, java.util.concurrent.TimeUnit.SECONDS);
                    if (resp == null) {
                        SwingUtilities.invokeLater(new Runnable() {
                            public void run() {
                                JOptionPane.showMessageDialog(RegistroCliente.this,
                                    "El servidor no respondio a tiempo.",
                                    "Sin respuesta", JOptionPane.WARNING_MESSAGE);
                            }
                        });
                        return;
                    }
                    final String datos = resp.getDatos();
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() { mostrarResultadoBusqueda(datos, dpi); }
                    });
                } catch (Exception ex) {
                    final String msg = ex.getMessage();
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            JOptionPane.showMessageDialog(RegistroCliente.this,
                                "Error en la busqueda: " + msg,
                                "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                }
            }
        }, "Thread-Buscar").start();
    }

    /**
     * Procesa el resultado RESULTADO_BUSQUEDA del servidor.
     * Formato esperado: "encontrado|nombre|apellido"   o   "no_encontrado"
     */
    private void mostrarResultadoBusqueda(String datos, String dpi) {
        if (datos == null || datos.startsWith("no_encontrado") || datos.startsWith("Sin registros")) {
            JOptionPane.showMessageDialog(this,
                "DPI no encontrado en el sistema.\n\n" +
                "Es la primera vez que se registra a este cliente.\n" +
                "Por favor ingresa nombre y apellido manualmente.",
                "DPI no encontrado", JOptionPane.INFORMATION_MESSAGE);
            txtNombre.requestFocus();
            return;
        }
        // Parsear "encontrado|nombre|apellido"
        String[] parts = datos.split("\\|");
        String nombre   = parts.length > 1 ? parts[1] : "";
        String apellido = parts.length > 2 ? parts[2] : "";

        int opt = JOptionPane.showConfirmDialog(this,
            "Cliente encontrado en el sistema:\n\n" +
            "   DPI:       " + dpi + "\n" +
            "   Nombre:    " + nombre + "\n" +
            "   Apellido:  " + apellido + "\n\n" +
            "Deseas autocompletar los campos?",
            "DPI encontrado", JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);

        if (opt == JOptionPane.YES_OPTION) {
            txtNombre.setText(nombre);
            txtApellido.setText(apellido);
        }
    }

    /**
     * Cambia los campos del panel segun el tipo de atencion seleccionado
     */
    private void actualizarPanelDinamico() {
        panelDinamico.removeAll();

        if (rbGeneral.isSelected()) {
            // 1-14 lamparas
            JLabel lbl = new JLabel("CANTIDAD DE LAMPARAS  (1-14)");
            lbl.setFont(new Font("Consolas", Font.BOLD, 11));
            lbl.setForeground(ACCENT2);
            lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            panelDinamico.add(lbl);
            panelDinamico.add(Box.createVerticalStrut(4));

            spnCantLampGeneral = new JSpinner(new SpinnerNumberModel(1, 1, 14, 1));
            spnCantLampGeneral.setFont(new Font("Consolas", Font.BOLD, 16));
            spnCantLampGeneral.setMaximumSize(new Dimension(100, 40));
            spnCantLampGeneral.setAlignmentX(Component.LEFT_ALIGNMENT);
            panelDinamico.add(spnCantLampGeneral);

        } else if (rbPrioritaria.isSelected()) {
            // Motivo + datos segun motivo
            JLabel lbl = new JLabel("MOTIVO DE ATENCION PRIORITARIA");
            lbl.setFont(new Font("Consolas", Font.BOLD, 11));
            lbl.setForeground(ACCENT2);
            lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            panelDinamico.add(lbl);
            panelDinamico.add(Box.createVerticalStrut(4));

            cbMotivoPrior = new JComboBox<String>(new String[]{
                "ADULTO MAYOR (>=60 anios)",
                "DISCAPACIDAD",
                "EMBARAZADA (>=4 meses)"
            });
            cbMotivoPrior.setFont(new Font("Consolas", Font.PLAIN, 13));
            cbMotivoPrior.setMaximumSize(new Dimension(400, 36));
            cbMotivoPrior.setAlignmentX(Component.LEFT_ALIGNMENT);
            cbMotivoPrior.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { actualizarSubMotivo(); }
            });
            panelDinamico.add(cbMotivoPrior);
            panelDinamico.add(Box.createVerticalStrut(8));

            // Subpanel: edad o meses
            JPanel sub = new JPanel();
            sub.setName("subMotivo");
            sub.setLayout(new BoxLayout(sub, BoxLayout.Y_AXIS));
            sub.setBackground(BG);
            sub.setAlignmentX(Component.LEFT_ALIGNMENT);
            panelDinamico.add(sub);

            actualizarSubMotivo();

            panelDinamico.add(Box.createVerticalStrut(10));

            // Cantidad lamparas tambien para prioritarios (1-14)
            JLabel lblL = new JLabel("CANTIDAD DE LAMPARAS  (1-14)");
            lblL.setFont(new Font("Consolas", Font.BOLD, 11));
            lblL.setForeground(ACCENT2);
            lblL.setAlignmentX(Component.LEFT_ALIGNMENT);
            panelDinamico.add(lblL);
            panelDinamico.add(Box.createVerticalStrut(4));

            spnCantLampGeneral = new JSpinner(new SpinnerNumberModel(1, 1, 14, 1));
            spnCantLampGeneral.setFont(new Font("Consolas", Font.BOLD, 16));
            spnCantLampGeneral.setMaximumSize(new Dimension(100, 40));
            spnCantLampGeneral.setAlignmentX(Component.LEFT_ALIGNMENT);
            panelDinamico.add(spnCantLampGeneral);

        } else if (rbEspecial.isSelected()) {
            // 15+ lamparas (mayoreo)
            JLabel lbl = new JLabel("CANTIDAD DE LAMPARAS  (mayoreo: 15 o mas)");
            lbl.setFont(new Font("Consolas", Font.BOLD, 11));
            lbl.setForeground(ACCENT2);
            lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            panelDinamico.add(lbl);
            panelDinamico.add(Box.createVerticalStrut(4));

            spnCantLampEspecial = new JSpinner(new SpinnerNumberModel(15, 15, 999, 5));
            spnCantLampEspecial.setFont(new Font("Consolas", Font.BOLD, 16));
            spnCantLampEspecial.setMaximumSize(new Dimension(120, 40));
            spnCantLampEspecial.setAlignmentX(Component.LEFT_ALIGNMENT);
            panelDinamico.add(spnCantLampEspecial);

            JLabel hint = new JLabel("Precios mayoreo: Basico Q80  |  Temporada Q230  |  Personalizado Q380+");
            hint.setFont(new Font("Consolas", Font.ITALIC, 10));
            hint.setForeground(TEXT_DIM);
            hint.setAlignmentX(Component.LEFT_ALIGNMENT);
            panelDinamico.add(Box.createVerticalStrut(6));
            panelDinamico.add(hint);
        }

        panelDinamico.revalidate();
        panelDinamico.repaint();
    }

    /**
     * Cambia el campo de edad/meses segun el motivo prioritario elegido
     */
    private void actualizarSubMotivo() {
        // Buscar el subpanel
        JPanel sub = null;
        for (Component c : panelDinamico.getComponents()) {
            if ("subMotivo".equals(c.getName())) { sub = (JPanel) c; break; }
        }
        if (sub == null) return;

        sub.removeAll();
        int idx = cbMotivoPrior.getSelectedIndex();

        if (idx == 0) { // Adulto Mayor
            JLabel l = new JLabel("EDAD");
            l.setFont(new Font("Consolas", Font.BOLD, 10));
            l.setForeground(TEXT_DIM);
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            sub.add(l);
            spnEdad = new JSpinner(new SpinnerNumberModel(60, 60, 120, 1));
            spnEdad.setFont(new Font("Consolas", Font.PLAIN, 14));
            spnEdad.setMaximumSize(new Dimension(80, 32));
            spnEdad.setAlignmentX(Component.LEFT_ALIGNMENT);
            sub.add(spnEdad);
        } else if (idx == 2) { // Embarazada
            JLabel l = new JLabel("MESES DE GESTACION  (4-9)");
            l.setFont(new Font("Consolas", Font.BOLD, 10));
            l.setForeground(TEXT_DIM);
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            sub.add(l);
            spnMesesGestacion = new JSpinner(new SpinnerNumberModel(4, 4, 9, 1));
            spnMesesGestacion.setFont(new Font("Consolas", Font.PLAIN, 14));
            spnMesesGestacion.setMaximumSize(new Dimension(80, 32));
            spnMesesGestacion.setAlignmentX(Component.LEFT_ALIGNMENT);
            sub.add(spnMesesGestacion);
        }
        // idx==1 (Discapacidad) no requiere mas datos

        sub.revalidate();
        sub.repaint();
    }

    private JLabel seccion(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(new Font("Consolas", Font.BOLD, 12));
        l.setForeground(ACCENT2);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        l.setBorder(new EmptyBorder(0, 0, 6, 0));
        return l;
    }

    private JTextField inputField(String name, int len) {
        JTextField t = new JTextField();
        t.setFont(new Font("Consolas", Font.PLAIN, 14));
        t.setBackground(CARD);
        t.setForeground(TEXT);
        t.setCaretColor(ACCENT);
        t.setBorder(new CompoundBorder(new LineBorder(CARD2, 1), new EmptyBorder(8, 10, 8, 10)));
        t.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        t.setAlignmentX(Component.LEFT_ALIGNMENT);
        return t;
    }

    private Component labeled(String label, JComponent input) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(BG);
        p.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel l = new JLabel(label);
        l.setFont(new Font("Consolas", Font.BOLD, 10));
        l.setForeground(TEXT_DIM);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        l.setBorder(new EmptyBorder(4, 0, 2, 0));
        p.add(l);
        p.add(input);
        return p;
    }

    private JRadioButton radio(String text, boolean selected) {
        JRadioButton r = new JRadioButton(text, selected);
        r.setFont(new Font("Consolas", Font.PLAIN, 12));
        r.setForeground(TEXT);
        r.setBackground(BG);
        r.setFocusPainted(false);
        r.setAlignmentX(Component.LEFT_ALIGNMENT);
        r.setBorder(new EmptyBorder(2, 0, 2, 0));
        return r;
    }

    private JPanel crearFooter() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(CARD2);
        p.setBorder(new EmptyBorder(8, 12, 8, 12));

        lblTicketGenerado = new JLabel("Listo para registrar...");
        lblTicketGenerado.setFont(new Font("Consolas", Font.BOLD, 14));
        lblTicketGenerado.setForeground(ACCENT);

        txtLog = new JTextArea(4, 50);
        txtLog.setFont(new Font("Consolas", Font.PLAIN, 10));
        txtLog.setBackground(BG);
        txtLog.setForeground(TEXT_DIM);
        txtLog.setEditable(false);
        JScrollPane scroll = new JScrollPane(txtLog);
        scroll.setBorder(null);

        p.add(lblTicketGenerado, BorderLayout.NORTH);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    // ══════════════════════════ REGISTRAR ════════════════════════════════
    private void registrar() {
        if (out == null) {
            JOptionPane.showMessageDialog(this, "No hay conexion al servidor.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        final String dpi = txtDPI.getText().trim();
        final String nombre = txtNombre.getText().trim();
        final String apellido = txtApellido.getText().trim();

        if (dpi.isEmpty() || dpi.length() < 13) {
            JOptionPane.showMessageDialog(this, "DPI invalido (minimo 13 digitos).", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (nombre.isEmpty() || apellido.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese nombre y apellido.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Determinar tipo y validar campos especificos
        boolean prioritario = rbPrioritaria.isSelected();
        String tipo = "GENERAL";
        int cantLamparas = 1;
        int edad = 0;
        boolean discap = false;
        int gest = 0;
        String motivoPrior = "";

        if (rbGeneral.isSelected()) {
            tipo = "GENERAL";
            cantLamparas = (Integer) spnCantLampGeneral.getValue();
        } else if (rbPrioritaria.isSelected()) {
            tipo = "PRIORITARIA";
            cantLamparas = (Integer) spnCantLampGeneral.getValue();
            int idx = cbMotivoPrior.getSelectedIndex();
            if (idx == 0) {
                motivoPrior = "MAYOR";
                edad = (Integer) spnEdad.getValue();
                if (edad < 60) {
                    JOptionPane.showMessageDialog(this, "La edad debe ser >= 60.", "Error", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            } else if (idx == 1) {
                motivoPrior = "DISCAPACIDAD";
                discap = true;
            } else {
                motivoPrior = "EMBARAZADA";
                gest = (Integer) spnMesesGestacion.getValue();
                if (gest < 4) {
                    JOptionPane.showMessageDialog(this, "Meses de gestacion debe ser >= 4.", "Error", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }
        } else if (rbEspecial.isSelected()) {
            tipo = "ESPECIAL";
            cantLamparas = (Integer) spnCantLampEspecial.getValue();
            if (cantLamparas < 15) {
                JOptionPane.showMessageDialog(this, "Mayoreo: minimo 15 lamparas.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }

        UsuarioPC2 u = new UsuarioPC2(dpi, "", prioritario);
        u.setNombre(nombre);
        u.setApellido(apellido);
        u.setTipoAtencion(tipo);
        u.setCantidadLamparas(cantLamparas);
        u.setEdad(edad);
        u.setDiscapacidad(discap);
        u.setMesesGestacion(gest);
        u.setMotivoPrioritario(motivoPrior);

        // Enviar al servidor
        btnRegistrar.setEnabled(false);
        final UsuarioPC2 finalU = u;
        new Thread(new Runnable() {
            public void run() {
                try {
                    synchronized (out) {
                        out.println(new MensajePC2(MensajePC2.REGISTRAR_USUARIO, finalU).toWire());
                    }
                    final MensajePC2 resp = colaRespuestas.poll(5, TimeUnit.SECONDS);
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            if (resp != null && MensajePC2.CONFIRMACION.equals(resp.getTipo())) {
                                lblTicketGenerado.setText(">> " + resp.getDatos());
                                lblTicketGenerado.setForeground(ACCENT);
                                txtDPI.setText("");
                                txtNombre.setText("");
                                txtApellido.setText("");
                                log("OK: " + resp.getDatos());
                            } else {
                                lblTicketGenerado.setText("Error en el registro");
                                lblTicketGenerado.setForeground(new Color(255, 100, 100));
                                log("Error o sin respuesta del servidor");
                            }
                            btnRegistrar.setEnabled(true);
                        }
                    });
                } catch (Exception e) {
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() { btnRegistrar.setEnabled(true); }
                    });
                }
            }
        }, "Thread-Registrar").start();
    }

    // ══════════════════════════ CONEXION ════════════════════════════════
    private void conectar() {
        new Thread(new Runnable() {
            public void run() {
                Properties config = cargarConfig();
                String ip = config.getProperty("server.ip", "localhost");
                int puerto = Integer.parseInt(config.getProperty("server.port", "5000"));
                int timeout  = Integer.parseInt(config.getProperty("client.timeout.ms", "2000"));

                int intento = 0;
                // Reintentar INFINITAMENTE hasta conectar
                while (true) {
                    intento++;
                    try {
                        if (intento == 1) {
                            actualizarEstadoConexion("CONECTANDO...", new Color(255, 180, 50));
                        } else {
                            actualizarEstadoConexion("RECONECTANDO (intento " + intento + ")", new Color(255, 100, 100));
                        }
                        socket = new Socket();
                        socket.connect(new java.net.InetSocketAddress(ip, puerto), timeout);
                        out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);
                        in  = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));

                        actualizarEstadoConexion("CONECTADO  Lumi3D Server", ACCENT);
                        log("Conectado al servidor (intento " + intento + ").");

                        synchronized (out) {
                            out.println(new MensajePC2(MensajePC2.IDENTIFICAR, "PC2-Registro").toWire());
                        }
                        if (chatPanel == null) {
                            SwingUtilities.invokeLater(new Runnable() {
                                public void run() { chatPanel = new ChatPanel("PC2-Registro", out); }
                            });
                        } else {
                            chatPanel.actualizarOut(out);
                        }

                        new Thread(new Runnable() {
                            public void run() { hiloLector(); }
                        }, "Thread-Lector").start();
                        return;
                    } catch (IOException e) {
                        log("Intento " + intento + ": " + e.getMessage());
                        try { Thread.sleep(timeout); } catch (InterruptedException ignored) {}
                    }
                }
            }
        }, "Thread-Conexion").start();
    }

    private void actualizarEstadoConexion(final String texto, final Color color) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                lblEstado.setText(texto);
                lblEstado.setForeground(color);
            }
        });
    }

    private void hiloLector() {
        try {
            String linea;
            while ((linea = in.readLine()) != null) {
                MensajePC2 m = MensajePC2.fromWire(linea);
                String tipo = m.getTipo();
                if (MensajePC2.CONFIRMACION.equals(tipo) ||
                    MensajePC2.ERROR.equals(tipo) ||
                    MensajePC2.RESULTADO_BUSQUEDA.equals(tipo)) {
                    colaRespuestas.put(m);
                } else if (MensajePC2.CHAT.equals(tipo)) {
                    if (chatPanel != null) chatPanel.recibirMensaje(m.getDatos());
                } else if (MensajePC2.BROADCAST_ESTADO.equals(tipo)) {
                    log("Colas: " + m.getDatos());
                }
            }
            // readLine devolvio null = servidor cerro la conexion
            manejarDesconexion("Servidor cerro la conexion");
        } catch (Exception e) {
            manejarDesconexion("Error de lectura: " + e.getMessage());
        }
    }

    private void manejarDesconexion(String motivo) {
        log("DESCONEXION: " + motivo);
        actualizarEstadoConexion("DESCONECTADO  -  Reconectando...", new Color(255, 100, 100));
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JOptionPane.showMessageDialog(
                    RegistroCliente.this,
                    "Conexion fallida con el servidor.\n\nReconectando automaticamente...",
                    "Servidor desconectado",
                    JOptionPane.WARNING_MESSAGE);
            }
        });
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        conectar();
    }

    private void log(final String msg) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                txtLog.append("[" + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) + "] " + msg + "\n");
                txtLog.setCaretPosition(txtLog.getDocument().getLength());
            }
        });
    }

    // ══════════════════════════ CONFIG ═══════════════════════════════════
    static Properties cargarConfig() {
        Properties p = new Properties();
        try {
            FileInputStream fis = new FileInputStream("config.properties");
            p.load(fis);
            fis.close();
        } catch (IOException e) {
            p.setProperty("server.ip", "localhost");
            p.setProperty("server.port", "5000");
            p.setProperty("client.reconnect.attempts", "5");
            p.setProperty("client.timeout.ms", "2000");
        }
        return p;
    }

    // ══════════════════════════ MAIN ═════════════════════════════════════
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
                catch (Exception ignored) {}
                new RegistroCliente();
            }
        });
    }
}
