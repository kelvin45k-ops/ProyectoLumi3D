@echo off
title PC1 - Lumi 3D
java -jar PC1.jar
pause
