@echo off
title PC5 - Lumi 3D
java -jar PC5.jar
pause
