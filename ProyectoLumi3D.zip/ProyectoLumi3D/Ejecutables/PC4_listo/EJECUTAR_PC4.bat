@echo off
title PC4 - Lumi 3D
java -jar PC4.jar
pause
