@echo off
title PC2 - Lumi 3D
java -jar PC2.jar
pause
