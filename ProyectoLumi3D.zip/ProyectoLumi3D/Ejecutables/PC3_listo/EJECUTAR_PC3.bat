@echo off
title PC3 - Lumi 3D
java -jar PC3.jar
pause
