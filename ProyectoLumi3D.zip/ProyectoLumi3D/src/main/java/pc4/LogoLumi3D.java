package pc4;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

/**
 * Componente Swing que dibuja el logo de Lumi3D vectorialmente.
 * No requiere archivos externos - se renderiza con Java2D.
 */
public class LogoLumi3D extends JComponent {

    private final int tam;
    private final boolean conTexto;

    private static final Color DORADO_OSCURO = new Color(168, 130, 30);
    private static final Color DORADO        = new Color(201, 162, 39);
    private static final Color DORADO_CLARO  = new Color(232, 199, 107);

    public LogoLumi3D(int tamano, boolean conTexto) {
        this.tam = tamano;
        this.conTexto = conTexto;
        int w = tamano;
        int h = conTexto ? (int)(tamano * 1.35) : tamano;
        setPreferredSize(new Dimension(w, h));
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);

        int s = tam;
        int cx = s / 2;
        int topY = s / 14;

        // Gradiente dorado para los trazos
        GradientPaint gradiente = new GradientPaint(
            0, 0, DORADO_CLARO,
            s, s, DORADO_OSCURO);
        g2.setPaint(gradiente);

        float trazo = Math.max(2f, s / 50f);
        g2.setStroke(new BasicStroke(trazo, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        // ───── Cabezal de impresion 3D (rectangulo arriba) ─────
        int cabezalW = s / 4;
        int cabezalH = s / 12;
        int cabezalX = cx - cabezalW / 2;
        int cabezalY = topY;
        g2.drawRect(cabezalX, cabezalY, cabezalW, cabezalH);

        // ───── Brazos horizontales del cabezal ─────
        int brazoY = cabezalY + cabezalH / 2;
        g2.drawLine(s / 12, brazoY, cabezalX, brazoY);
        g2.drawLine(cabezalX + cabezalW, brazoY, s - s / 12, brazoY);

        // ───── Boquilla extrusora (triangulo invertido) ─────
        int boqTop = cabezalY + cabezalH;
        int boqBot = boqTop + s / 12;
        Path2D boquilla = new Path2D.Float();
        boquilla.moveTo(cx - s/22, boqTop);
        boquilla.lineTo(cx + s/22, boqTop);
        boquilla.lineTo(cx, boqBot);
        boquilla.closePath();
        g2.draw(boquilla);

        // ───── Hilo de extrusion ─────
        int hiloTop = boqBot;
        int hiloBot = hiloTop + s / 16;
        g2.drawLine(cx, hiloTop, cx, hiloBot);

        // ───── Cubo isometrico 3D ─────
        int cuboCY = (int)(s * 0.58);
        int cuboTam = (int)(s * 0.42);
        dibujarCuboIsometrico(g2, cx, cuboCY, cuboTam);

        // ───── Texto "Lumi3D" si corresponde ─────
        if (conTexto) {
            int fontSize = s / 5;
            g2.setFont(new Font("Serif", Font.BOLD, fontSize));
            FontMetrics fm = g2.getFontMetrics();
            String txt = "Lumi3D";
            int tw = fm.stringWidth(txt);
            int tx = cx - tw / 2;
            int ty = (int)(s * 1.18);
            g2.setPaint(gradiente);
            g2.drawString(txt, tx, ty);
        }

        g2.dispose();
    }

    private void dibujarCuboIsometrico(Graphics2D g2, int cx, int cy, int tam) {
        int r = tam / 2;
        // Vertices de un cubo isometrico
        // Top center, top-right back, top-left back, top-front
        Point top  = new Point(cx, cy - r);
        Point tr   = new Point(cx + r, cy - r/2);
        Point bbR  = new Point(cx + r, cy + r/2);
        Point bot  = new Point(cx, cy + r);
        Point bbL  = new Point(cx - r, cy + r/2);
        Point tl   = new Point(cx - r, cy - r/2);
        Point cnt  = new Point(cx, cy);

        // Hexagono exterior
        Path2D hex = new Path2D.Float();
        hex.moveTo(top.x, top.y);
        hex.lineTo(tr.x, tr.y);
        hex.lineTo(bbR.x, bbR.y);
        hex.lineTo(bot.x, bot.y);
        hex.lineTo(bbL.x, bbL.y);
        hex.lineTo(tl.x, tl.y);
        hex.closePath();
        g2.draw(hex);

        // Lineas internas que forman el efecto 3D
        g2.drawLine(cnt.x, cnt.y, top.x, top.y);
        g2.drawLine(cnt.x, cnt.y, bbR.x, bbR.y);
        g2.drawLine(cnt.x, cnt.y, bbL.x, bbL.y);

        // Brazos horizontales (extension del cubo)
        int brazoExt = tam / 3;
        g2.drawLine(bbL.x - brazoExt, cy + r/4, bbL.x, cy + r/2);
        g2.drawLine(bbR.x, cy + r/2, bbR.x + brazoExt, cy + r/4);
    }
}
