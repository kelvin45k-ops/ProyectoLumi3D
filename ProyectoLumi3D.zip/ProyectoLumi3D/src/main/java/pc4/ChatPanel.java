package pc4;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.PrintWriter;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Ventana de chat global. Cada PC abre una instancia.
 * Recibe mensajes del servidor y envia mensajes al servidor para difusion.
 */
public class ChatPanel extends JFrame {

    private final String miNombre;
    private PrintWriter out;
    private final JTextArea txtChat;
    private final JTextField txtInput;

    private static final Color BG     = new Color(245, 245, 245);
    private static final Color CARD   = new Color(255, 255, 255);
    private static final Color BORDER = new Color(181, 181, 181);
    private static final Color ACCENT = new Color(201, 162, 39);
    private static final Color TEXT   = new Color(44, 44, 44);

    public ChatPanel(String miNombre, PrintWriter out) {
        this.miNombre = miNombre;
        this.out = out;

        setTitle("CHAT GRUPAL - " + miNombre);
        setSize(500, 500);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout(0, 0));

        JLabel header = new JLabel("  CHAT GLOBAL  -  " + miNombre);
        header.setFont(new Font("Consolas", Font.BOLD, 16));
        header.setForeground(ACCENT);
        header.setBackground(CARD);
        header.setOpaque(true);
        header.setBorder(new EmptyBorder(12, 16, 12, 16));

        txtChat = new JTextArea();
        txtChat.setFont(new Font("Consolas", Font.PLAIN, 13));
        txtChat.setBackground(BG);
        txtChat.setForeground(TEXT);
        txtChat.setEditable(false);
        txtChat.setLineWrap(true);
        txtChat.setWrapStyleWord(true);
        txtChat.setMargin(new Insets(8, 12, 8, 12));
        JScrollPane scroll = new JScrollPane(txtChat);
        scroll.setBorder(new EmptyBorder(8, 8, 4, 8));
        scroll.getViewport().setBackground(BG);

        txtInput = new JTextField();
        txtInput.setFont(new Font("Consolas", Font.PLAIN, 13));
        txtInput.setBackground(CARD);
        txtInput.setForeground(TEXT);
        txtInput.setCaretColor(ACCENT);
        txtInput.setBorder(new CompoundBorder(new LineBorder(ACCENT, 2), new EmptyBorder(8, 10, 8, 10)));

        JButton btnEnviar = new JButton("ENVIAR");
        btnEnviar.setFont(new Font("Consolas", Font.BOLD, 13));
        btnEnviar.setForeground(Color.WHITE);
        btnEnviar.setBackground(ACCENT);
        btnEnviar.setBorder(new EmptyBorder(8, 16, 8, 16));
        btnEnviar.setFocusPainted(false);
        btnEnviar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        ActionListener enviar = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String texto = txtInput.getText().trim();
                if (texto.isEmpty()) return;
                String wire = new MensajePC4(MensajePC4.CHAT, miNombre + "||" + texto).toWire();
                if (out != null) {
                    synchronized (out) { out.println(wire); }
                }
                txtInput.setText("");
            }
        };
        btnEnviar.addActionListener(enviar);
        txtInput.addActionListener(enviar);

        JPanel inputPanel = new JPanel(new BorderLayout(6, 0));
        inputPanel.setBackground(BG);
        inputPanel.setBorder(new EmptyBorder(4, 8, 12, 8));
        inputPanel.add(txtInput, BorderLayout.CENTER);
        inputPanel.add(btnEnviar, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.SOUTH);

        agregarSistema("Conectado al chat. Los mensajes se envian a todos los PCs.");
    }

    /**
     * Llamado cuando el cliente recibe un mensaje CHAT del servidor.
     * Formato del payload: "origen||texto"
     */
    public void recibirMensaje(String datos) {
        if (datos == null) return;
        int sep = datos.indexOf("||");
        final String origen = sep > 0 ? datos.substring(0, sep) : "?";
        final String texto  = sep > 0 ? datos.substring(sep + 2) : datos;
        final String hora = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        final ChatPanel self = this;
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                txtChat.append("[" + hora + "] " + origen + ": " + texto + "\n");
                txtChat.setCaretPosition(txtChat.getDocument().getLength());
                // Auto-mostrar la ventana si no esta visible para que el usuario vea el mensaje
                if (!self.isVisible()) {
                    self.setVisible(true);
                    self.toFront();
                }
                // Parpadeo visual: cambiar titulo
                self.setTitle("CHAT * NUEVO MENSAJE - " + miNombre);
                javax.swing.Timer t = new javax.swing.Timer(2000, new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent e) {
                        self.setTitle("CHAT GRUPAL - " + miNombre);
                    }
                });
                t.setRepeats(false);
                t.start();
            }
        });
    }

    private void agregarSistema(final String texto) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                txtChat.append("--- " + texto + " ---\n");
                txtChat.setCaretPosition(txtChat.getDocument().getLength());
            }
        });
    }

    /**
     * Actualiza el PrintWriter cuando hay reconexion al servidor.
     */
    public void actualizarOut(PrintWriter newOut) {
        this.out = newOut;
    }
}
