package pc1;

/**
 * Mensaje de protocolo - cada PC tiene su propia version.
 * Los PCs se comunican via texto plano (metodo toWire / fromWire).
 * No se usa serializacion Java, por lo que el nombre de la clase puede
 * ser distinto en cada PC sin afectar la comunicacion.
 */
public class MensajePC1 {

    // Constantes de tipo de mensaje - deben ser iguales en los 5 PCs
    public static final String REGISTRAR_USUARIO               = "REGISTRAR_USUARIO";
    public static final String SOLICITAR_SIGUIENTE_GENERAL     = "SOLICITAR_SIGUIENTE_GENERAL";
    public static final String SOLICITAR_SIGUIENTE_PRIORITARIO = "SOLICITAR_SIGUIENTE_PRIORITARIO";
    public static final String SOLICITAR_SIGUIENTE_ESPECIAL    = "SOLICITAR_SIGUIENTE_ESPECIAL";
    public static final String FINALIZAR_ATENCION              = "FINALIZAR_ATENCION";
    public static final String USUARIO_ASIGNADO                = "USUARIO_ASIGNADO";
    public static final String COLA_VACIA                      = "COLA_VACIA";
    public static final String CONFIRMACION                    = "CONFIRMACION";
    public static final String ERROR                           = "ERROR";
    public static final String BROADCAST_ESTADO                = "BROADCAST_ESTADO";
    public static final String BUSCAR_DPI                      = "BUSCAR_DPI";
    public static final String RESULTADO_BUSQUEDA              = "RESULTADO_BUSQUEDA";
    // Chat e identificacion de PCs
    public static final String IDENTIFICAR                     = "IDENTIFICAR";
    public static final String CHAT                            = "CHAT";
    public static final String LISTA_PCS                       = "LISTA_PCS";

    private String tipo;
    private UsuarioPC1 usuario;
    private String datos;

    public MensajePC1(String tipo) {
        this.tipo = tipo;
    }

    public MensajePC1(String tipo, UsuarioPC1 usuario) {
        this.tipo = tipo;
        this.usuario = usuario;
    }

    public MensajePC1(String tipo, String datos) {
        this.tipo = tipo;
        this.datos = datos;
    }

    /**
     * Codifica el mensaje a una linea de texto:
     *   TIPO##USR##<campos_usuario>       si lleva usuario
     *   TIPO##DAT##<datos>                si lleva datos
     *   TIPO                              si va solo
     */
    public String toWire() {
        StringBuilder sb = new StringBuilder();
        sb.append(tipo);
        if (usuario != null) {
            sb.append("##USR##").append(usuario.toWire());
        } else if (datos != null) {
            String d = datos.replace("\n", " ").replace("\r", " ");
            sb.append("##DAT##").append(d);
        }
        return sb.toString();
    }

    /**
     * Decodifica una linea de texto recibida por el socket
     */
    public static MensajePC1 fromWire(String linea) {
        if (linea == null) return new MensajePC1(ERROR, "null");
        int sep = linea.indexOf("##");
        String tipo;
        String resto = "";
        if (sep < 0) {
            tipo = linea;
        } else {
            tipo = linea.substring(0, sep);
            resto = linea.substring(sep + 2);
        }
        MensajePC1 m = new MensajePC1(tipo);
        if (resto.startsWith("USR##")) {
            m.usuario = UsuarioPC1.fromWire(resto.substring(5));
        } else if (resto.startsWith("DAT##")) {
            m.datos = resto.substring(5);
        }
        return m;
    }

    // Getters y Setters
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public UsuarioPC1 getUsuario() { return usuario; }
    public void setUsuario(UsuarioPC1 usuario) { this.usuario = usuario; }
    public String getDatos() { return datos; }
    public void setDatos(String datos) { this.datos = datos; }
}
