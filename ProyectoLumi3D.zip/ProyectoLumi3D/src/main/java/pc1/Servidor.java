package pc1;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class Servidor extends JFrame {

    // ══════════════════════════ ESTADO ══════════════════════════════════
    private final Queue<UsuarioPC1> colaGeneral             = new LinkedList<UsuarioPC1>();
    private final PriorityQueue<UsuarioPC1> colaPrioritaria = new PriorityQueue<UsuarioPC1>();
    private final Queue<UsuarioPC1> colaEspecial            = new LinkedList<UsuarioPC1>();
    private final Map<String, UsuarioPC1> enAtencion        = new ConcurrentHashMap<String, UsuarioPC1>();
    private final BPlusTreePC1 arbolHistorial               = new BPlusTreePC1(5);
    private final List<PrintWriter> clientes                = new CopyOnWriteArrayList<PrintWriter>();
    private final Map<PrintWriter, String> nombrePorCliente = new ConcurrentHashMap<PrintWriter, String>();
    private final AtomicInteger contadorTickets             = new AtomicInteger(1);
    private final Stack<UsuarioPC1> ultimosAtendidos        = new Stack<UsuarioPC1>();

    private static final String ARCHIVO_CSV = "atenciones.csv";
    private int puerto;

    // ══════════════════════════ GUI ══════════════════════════════════════
    private DefaultTableModel modeloGeneral, modeloPrioritario, modeloEspecial;
    private DefaultListModel<String> modeloPCs;
    private JLabel lblGeneral, lblPrioritario, lblEspecial, lblTotal, lblEstado, lblConectados;
    private JTextField txtBuscarDPI, txtChatServidor;
    private JTextArea txtResultadoBusqueda;
    private JTextArea txtLog, txtChat;
    private JTabbedPane tabsDerecha;

    // ──────── PALETA LUMI 3D - TEMA CLARO ────────
    private static final Color BG_DARK     = new Color(210, 210, 210);  // gris ceniza fondo
    private static final Color BG_CARD     = new Color(255, 255, 255);  // tarjetas blancas
    private static final Color BG_CARD2    = new Color(238, 238, 238);  // tarjetas alt
    private static final Color BORDER      = new Color(181, 181, 181);  // bordes
    private static final Color ACCENT      = new Color(201, 162, 39);   // dorado Lumi
    private static final Color ACCENT2     = new Color(168, 130, 30);   // dorado oscuro
    private static final Color PRIORITARIO = new Color(224, 142, 69);   // naranja
    private static final Color ESPECIAL    = new Color(140, 80, 180);   // morado mate
    private static final Color OK_GREEN    = new Color(95, 170, 95);    // verde exito
    private static final Color DANGER      = new Color(200, 80, 80);    // rojo error
    private static final Color TEXT_MAIN   = new Color(44, 44, 44);     // texto oscuro
    private static final Color TEXT_DIM    = new Color(102, 102, 102);  // texto secundario
    private static final Font FONT_TITLE   = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_LABEL   = new Font("Segoe UI", Font.BOLD, 12);
    private static final Font FONT_MONO    = new Font("Consolas", Font.PLAIN, 12);

    public Servidor(int puerto) {
        this.puerto = puerto;
        cargarHistorialCSV();
        initGUI();
        iniciarServidor();
        setVisible(true);
    }

    private void initGUI() {
        setTitle("SERVIDOR CENTRAL - SISTEMA DE COLAS");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1700, 900);
        setMinimumSize(new Dimension(1400, 800));
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_DARK);
        setLayout(new BorderLayout(10, 10));
        add(crearHeader(), BorderLayout.NORTH);
        add(crearPanelCentral(), BorderLayout.CENTER);
        add(crearPanelDerecho(), BorderLayout.EAST);
        add(crearFooter(), BorderLayout.SOUTH);
    }

    private JPanel crearHeader() {
        JPanel p = new JPanel(new BorderLayout(15, 0));
        p.setBackground(BG_CARD);
        p.setBorder(new CompoundBorder(
            new MatteBorder(0, 0, 2, 0, ACCENT),
            new EmptyBorder(14, 24, 14, 24)));

        // Lado izquierdo: logo + titulo
        JPanel ladoIzq = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        ladoIzq.setOpaque(false);
        ladoIzq.add(new LogoLumi3D(60, false));

        JPanel titulos = new JPanel();
        titulos.setLayout(new BoxLayout(titulos, BoxLayout.Y_AXIS));
        titulos.setOpaque(false);
        JLabel titleMain = new JLabel("Lumi 3D");
        titleMain.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titleMain.setForeground(ACCENT);
        JLabel titleSub = new JLabel("Sistema de Gestion de Colas - Servidor Central");
        titleSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        titleSub.setForeground(TEXT_DIM);
        titulos.add(titleMain);
        titulos.add(titleSub);
        ladoIzq.add(titulos);

        // Lado derecho: badges
        JPanel stats = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        stats.setOpaque(false);

        lblGeneral     = badge("GENERAL", "0", new Color(120, 160, 200));
        lblPrioritario = badge("PRIORITARIO", "0", PRIORITARIO);
        lblEspecial    = badge("ESPECIAL", "0", ESPECIAL);
        lblTotal       = badge("ATENDIDOS", "0", ACCENT);
        lblConectados  = badge("PCs", "0", new Color(80, 130, 80));
        lblEstado      = new JLabel("INICIANDO");
        lblEstado.setFont(FONT_LABEL);
        lblEstado.setForeground(PRIORITARIO);

        stats.add(lblGeneral);
        stats.add(lblPrioritario);
        stats.add(lblEspecial);
        stats.add(lblTotal);
        stats.add(lblConectados);
        stats.add(lblEstado);

        p.add(ladoIzq, BorderLayout.WEST);
        p.add(stats, BorderLayout.EAST);
        return p;
    }

    private JLabel badge(String titulo, String valor, Color color) {
        JLabel l = new JLabel(titulo + ": " + valor);
        l.setFont(FONT_LABEL);
        l.setForeground(color);
        l.setBorder(new CompoundBorder(
            new LineBorder(color, 1, true),
            new EmptyBorder(5, 12, 5, 12)));
        l.setOpaque(true);
        // Fondo blanquecino tenido del color
        l.setBackground(new Color(
            Math.min(255, color.getRed()   + (255-color.getRed())*4/5),
            Math.min(255, color.getGreen() + (255-color.getGreen())*4/5),
            Math.min(255, color.getBlue()  + (255-color.getBlue())*4/5)));
        return l;
    }

    private JPanel crearPanelCentral() {
        JPanel p = new JPanel(new GridLayout(1, 3, 10, 0));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(0, 10, 0, 0));
        modeloGeneral     = crearModelo();
        modeloPrioritario = crearModelo();
        modeloEspecial    = crearModelo();
        p.add(panelCola("COLA GENERAL", modeloGeneral, new Color(120, 160, 200)));
        p.add(panelCola("COLA PRIORITARIA", modeloPrioritario, PRIORITARIO));
        p.add(panelCola("COLA ESPECIAL", modeloEspecial, ESPECIAL));
        return p;
    }

    private DefaultTableModel crearModelo() {
        return new DefaultTableModel(new String[]{"Ticket", "DPI", "Estado", "Espera"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
    }

    private JPanel panelCola(String titulo, DefaultTableModel modelo, Color accentColor) {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBackground(BG_CARD);
        p.setBorder(new CompoundBorder(new LineBorder(accentColor, 1), new EmptyBorder(12, 12, 12, 12)));
        JLabel lbl = new JLabel(titulo);
        lbl.setFont(new Font("Consolas", Font.BOLD, 13));
        lbl.setForeground(accentColor);
        JTable tabla = new JTable(modelo);
        tabla.setBackground(BG_DARK);
        tabla.setForeground(TEXT_MAIN);
        tabla.setFont(FONT_MONO);
        tabla.setRowHeight(26);
        tabla.setGridColor(BG_CARD2);
        tabla.getTableHeader().setBackground(BG_CARD2);
        tabla.getTableHeader().setForeground(accentColor);
        tabla.getTableHeader().setFont(FONT_LABEL);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(BG_DARK);
        p.add(lbl, BorderLayout.NORTH);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    /**
     * Panel derecho con tabs: Busqueda, Chat, PCs Conectados, Log
     */
    private JPanel crearPanelDerecho() {
        JPanel p = new JPanel(new BorderLayout());
        p.setPreferredSize(new Dimension(500, 0));
        p.setBackground(BG_CARD);
        p.setBorder(new CompoundBorder(new LineBorder(ACCENT, 1), new EmptyBorder(8, 8, 8, 8)));

        // ─── MITAD SUPERIOR: BUSQUEDA (sin tab) ───
        JPanel panelBusqueda = crearTabBusqueda();

        // ─── MITAD INFERIOR: TABS con CHAT / PCs / LOG ───
        JTabbedPane tabs = new JTabbedPane();
        tabsDerecha = tabs;
        tabs.setFont(FONT_LABEL);
        tabs.setBackground(BG_CARD);
        tabs.setForeground(TEXT_MAIN);

        tabs.addTab("CHAT", crearTabChat());
        tabs.addTab("PCs CONECTADOS", crearTabPCs());
        tabs.addTab("LOG", crearTabLog());
        tabs.setSelectedIndex(0); // CHAT como pestaña inicial

        // Cuando el usuario abre la pestaña CHAT (ahora indice 0), eliminar el asterisco
        tabs.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent e) {
                if (tabs.getSelectedIndex() == 0) {
                    tabs.setTitleAt(0, "CHAT");
                    tabs.setForegroundAt(0, TEXT_MAIN);
                }
            }
        });

        // ─── DIVISOR VERTICAL (split en dos mitades) ───
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, panelBusqueda, tabs);
        split.setResizeWeight(0.5);         // 50% arriba / 50% abajo
        split.setContinuousLayout(true);
        split.setBorder(null);
        split.setBackground(BG_CARD);
        split.setDividerSize(8);

        p.add(split, BorderLayout.CENTER);
        return p;
    }

    private JPanel crearTabBusqueda() {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBackground(BG_CARD);
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel lblBusqueda = new JLabel("BUSQUEDA POR DPI (Arbol B+)");
        lblBusqueda.setFont(new Font("Consolas", Font.BOLD, 14));
        lblBusqueda.setForeground(ACCENT2);

        txtBuscarDPI = new JTextField();
        txtBuscarDPI.setFont(new Font("Consolas", Font.PLAIN, 14));
        txtBuscarDPI.setBackground(BG_DARK);
        txtBuscarDPI.setForeground(TEXT_MAIN);
        txtBuscarDPI.setCaretColor(ACCENT2);
        txtBuscarDPI.setBorder(new CompoundBorder(new LineBorder(ACCENT, 2), new EmptyBorder(8, 10, 8, 10)));
        txtBuscarDPI.setPreferredSize(new Dimension(0, 38));

        JButton btnBuscar = crearBoton("BUSCAR", ACCENT);
        btnBuscar.setPreferredSize(new Dimension(100, 38));
        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { buscarPorDPI(); }
        });
        txtBuscarDPI.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { buscarPorDPI(); }
        });

        JButton btnHistorial = crearBoton("VER HISTORIAL COMPLETO", ACCENT);
        btnHistorial.setPreferredSize(new Dimension(0, 32));
        btnHistorial.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { mostrarHistorialCompleto(); }
        });

        txtResultadoBusqueda = new JTextArea();
        txtResultadoBusqueda.setFont(new Font("Consolas", Font.PLAIN, 12));
        txtResultadoBusqueda.setBackground(BG_DARK);
        txtResultadoBusqueda.setForeground(TEXT_MAIN);
        txtResultadoBusqueda.setEditable(false);
        txtResultadoBusqueda.setMargin(new Insets(8, 10, 8, 10));
        JScrollPane scroll = new JScrollPane(txtResultadoBusqueda);
        scroll.setBorder(new LineBorder(BG_CARD2));

        JPanel busqPanel = new JPanel(new BorderLayout(6, 4));
        busqPanel.setOpaque(false);
        busqPanel.add(txtBuscarDPI, BorderLayout.CENTER);
        busqPanel.add(btnBuscar, BorderLayout.EAST);

        JPanel topPanel = new JPanel(new BorderLayout(0, 6));
        topPanel.setOpaque(false);
        topPanel.add(lblBusqueda, BorderLayout.NORTH);
        JPanel barra = new JPanel(new BorderLayout(0, 6));
        barra.setOpaque(false);
        barra.add(busqPanel, BorderLayout.NORTH);
        barra.add(btnHistorial, BorderLayout.CENTER);
        topPanel.add(barra, BorderLayout.CENTER);

        p.add(topPanel, BorderLayout.NORTH);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    private JPanel crearTabChat() {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBackground(BG_CARD);
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel lbl = new JLabel("CHAT GRUPAL  (todos los PCs conectados)");
        lbl.setFont(new Font("Consolas", Font.BOLD, 14));
        lbl.setForeground(ESPECIAL);

        txtChat = new JTextArea();
        txtChat.setFont(new Font("Consolas", Font.PLAIN, 12));
        txtChat.setBackground(BG_DARK);
        txtChat.setForeground(TEXT_MAIN);
        txtChat.setEditable(false);
        txtChat.setLineWrap(true);
        txtChat.setWrapStyleWord(true);
        txtChat.setMargin(new Insets(8, 10, 8, 10));
        JScrollPane scrollChat = new JScrollPane(txtChat);
        scrollChat.setBorder(new LineBorder(BG_CARD2));

        // Caja para que el SERVIDOR tambien participe en el chat
        txtChatServidor = new JTextField();
        txtChatServidor.setFont(new Font("Consolas", Font.PLAIN, 13));
        txtChatServidor.setBackground(BG_DARK);
        txtChatServidor.setForeground(TEXT_MAIN);
        txtChatServidor.setCaretColor(ESPECIAL);
        txtChatServidor.setBorder(new CompoundBorder(new LineBorder(ESPECIAL, 2), new EmptyBorder(8, 10, 8, 10)));
        txtChatServidor.setPreferredSize(new Dimension(0, 38));

        JButton btnEnviar = crearBoton("ENVIAR", ESPECIAL);
        btnEnviar.setPreferredSize(new Dimension(100, 38));

        ActionListener enviarServ = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String txt = txtChatServidor.getText().trim();
                if (txt.isEmpty()) return;
                difundirChat("PC1-Servidor", txt);
                txtChatServidor.setText("");
            }
        };
        btnEnviar.addActionListener(enviarServ);
        txtChatServidor.addActionListener(enviarServ);

        JPanel inputChat = new JPanel(new BorderLayout(4, 0));
        inputChat.setOpaque(false);
        inputChat.add(txtChatServidor, BorderLayout.CENTER);
        inputChat.add(btnEnviar, BorderLayout.EAST);

        p.add(lbl, BorderLayout.NORTH);
        p.add(scrollChat, BorderLayout.CENTER);
        p.add(inputChat, BorderLayout.SOUTH);
        return p;
    }

    private JPanel crearTabPCs() {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBackground(BG_CARD);
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel lbl = new JLabel("PCs CONECTADOS EN TIEMPO REAL");
        lbl.setFont(new Font("Consolas", Font.BOLD, 14));
        lbl.setForeground(ACCENT);

        modeloPCs = new DefaultListModel<String>();
        JList<String> listaPCs = new JList<String>(modeloPCs);
        listaPCs.setFont(new Font("Consolas", Font.BOLD, 14));
        listaPCs.setBackground(BG_DARK);
        listaPCs.setForeground(TEXT_MAIN);
        listaPCs.setCellRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                            boolean isSelected, boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                label.setBorder(new EmptyBorder(8, 12, 8, 12));
                String text = value.toString();
                if (text.contains("Servidor")) label.setForeground(ESPECIAL);
                else if (text.contains("Registro")) label.setForeground(OK_GREEN);
                else if (text.contains("General")) label.setForeground(new Color(120, 160, 200));
                else if (text.contains("Prioritaria")) label.setForeground(PRIORITARIO);
                else if (text.contains("Especial")) label.setForeground(ESPECIAL);
                else label.setForeground(TEXT_MAIN);
                if (!isSelected) label.setBackground(BG_DARK);
                return label;
            }
        });

        JScrollPane scroll = new JScrollPane(listaPCs);
        scroll.setBorder(new LineBorder(BG_CARD2));

        // El servidor mismo siempre está "conectado"
        modeloPCs.addElement("● PC1 - Servidor (este equipo)");

        p.add(lbl, BorderLayout.NORTH);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    private JPanel crearTabLog() {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBackground(BG_CARD);
        p.setBorder(new EmptyBorder(10, 10, 10, 10));
        JLabel lbl = new JLabel("LOG DEL SISTEMA");
        lbl.setFont(new Font("Consolas", Font.BOLD, 14));
        lbl.setForeground(ACCENT);
        txtLog = new JTextArea();
        txtLog.setFont(new Font("Consolas", Font.PLAIN, 11));
        txtLog.setBackground(BG_DARK);
        txtLog.setForeground(TEXT_DIM);
        txtLog.setEditable(false);
        JScrollPane scrollLog = new JScrollPane(txtLog);
        scrollLog.setBorder(new LineBorder(BG_CARD2));
        p.add(lbl, BorderLayout.NORTH);
        p.add(scrollLog, BorderLayout.CENTER);
        return p;
    }

    private JPanel crearFooter() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 6));
        p.setBackground(BG_CARD2);
        JButton btnLimpiar = crearBoton("LIMPIAR LOG", TEXT_DIM);
        btnLimpiar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { txtLog.setText(""); }
        });
        p.add(btnLimpiar);
        JLabel info = new JLabel("Puerto: " + puerto + "  |  Arbol B+ Orden 5  |  Persistencia: " + ARCHIVO_CSV);
        info.setFont(new Font("Consolas", Font.PLAIN, 11));
        info.setForeground(TEXT_DIM);
        p.add(info);
        return p;
    }

    private JButton crearBoton(String texto, Color color) {
        JButton b = new JButton(texto);
        b.setFont(FONT_LABEL);
        b.setForeground(Color.WHITE);
        b.setBackground(color);
        b.setBorder(new EmptyBorder(7, 16, 7, 16));
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setOpaque(true);
        return b;
    }

    // ══════════════════════════ SOCKET SERVER ═════════════════════════
    private void iniciarServidor() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    ServerSocket ss = new ServerSocket(puerto);
                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            lblEstado.setText("EN LINEA :" + puerto);
                            lblEstado.setForeground(OK_GREEN);
                        }
                    });
                    log("Servidor iniciado en puerto " + puerto);
                    while (true) {
                        Socket cliente = ss.accept();
                        log("Cliente conectado: " + cliente.getInetAddress());
                        new Thread(new ManejadorCliente(cliente)).start();
                    }
                } catch (IOException e) { log("ERROR servidor: " + e.getMessage()); }
            }
        }, "Thread-Servidor").start();
    }

    // ══════════════════════════ CLIENT HANDLER ══════════════════════════
    private class ManejadorCliente implements Runnable {
        private final Socket socket;
        private PrintWriter out;
        private String nombrePC = "Cliente";

        ManejadorCliente(Socket s) { this.socket = s; }

        public void run() {
            BufferedReader in = null;
            try {
                in  = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
                out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);
                clientes.add(out);
                String linea;
                while ((linea = in.readLine()) != null) {
                    procesarMensaje(MensajePC1.fromWire(linea), out);
                }
            } catch (IOException e) {
                log("Cliente desconectado: " + nombrePC);
            } finally {
                if (out != null) {
                    clientes.remove(out);
                    String desconectado = nombrePorCliente.remove(out);
                    if (desconectado != null) {
                        actualizarListaPCs();
                        difundirChat("Sistema", desconectado + " se ha desconectado");
                    }
                }
                try { socket.close(); } catch (IOException ignored) {}
            }
        }

        private void procesarMensaje(MensajePC1 msg, PrintWriter out) {
            String tipo = msg.getTipo();

            // ── Identificacion (no requiere lock de colas) ──
            if (MensajePC1.IDENTIFICAR.equals(tipo)) {
                String nombre = msg.getDatos();
                if (nombre == null || nombre.isEmpty()) nombre = "Cliente desconocido";
                this.nombrePC = nombre;
                nombrePorCliente.put(out, nombre);
                log("Identificado: " + nombre);
                actualizarListaPCs();
                difundirChat("Sistema", nombre + " se ha conectado");
                return;
            }

            // ── Chat (no requiere lock de colas) ──
            if (MensajePC1.CHAT.equals(tipo)) {
                String datos = msg.getDatos();
                if (datos == null) return;
                int sep = datos.indexOf("||");
                String origen = sep > 0 ? datos.substring(0, sep) : nombrePC;
                String texto  = sep > 0 ? datos.substring(sep + 2) : datos;
                difundirChat(origen, texto);
                return;
            }

            // ── Operaciones de cola (requieren sincronizacion) ──
            synchronized (Servidor.this) {
                if (MensajePC1.REGISTRAR_USUARIO.equals(tipo)) {
                    UsuarioPC1 u = msg.getUsuario();
                    u.setTicket(generarTicket(u.isPrioritario()));
                    if (u.isPrioritario()) colaPrioritaria.offer(u);
                    else if ("ESPECIAL".equals(u.getTipoAtencion())) colaEspecial.offer(u);
                    else colaGeneral.offer(u);
                    log("Registrado: " + u);
                    out.println(new MensajePC1(MensajePC1.CONFIRMACION, "Ticket: " + u.getTicket()).toWire());
                    actualizarGUI();
                    broadcast();
                } else if (MensajePC1.SOLICITAR_SIGUIENTE_GENERAL.equals(tipo)) {
                    entregarUsuario(colaGeneral.poll(), out);
                } else if (MensajePC1.SOLICITAR_SIGUIENTE_PRIORITARIO.equals(tipo)) {
                    entregarUsuario(colaPrioritaria.poll(), out);
                } else if (MensajePC1.SOLICITAR_SIGUIENTE_ESPECIAL.equals(tipo)) {
                    entregarUsuario(colaEspecial.poll(), out);
                } else if (MensajePC1.FINALIZAR_ATENCION.equals(tipo)) {
                    UsuarioPC1 u = msg.getUsuario();
                    u.setEstado("ATENDIDO");
                    enAtencion.remove(u.getTicket());
                    ultimosAtendidos.push(u);
                    arbolHistorial.insertar(u.getDpi(), u);
                    guardarCSV(u);
                    out.println(new MensajePC1(MensajePC1.CONFIRMACION, "OK").toWire());
                    log("Finalizado: " + u.getTicket() + " - " + u.getNombre());
                    actualizarGUI();
                } else if (MensajePC1.BUSCAR_DPI.equals(tipo)) {
                    String dpiBuscado = msg.getDatos();
                    List<UsuarioPC1> resultados = arbolHistorial.buscar(dpiBuscado);
                    // Filtrar solo coincidencias EXACTAS
                    UsuarioPC1 encontrado = null;
                    for (UsuarioPC1 u : resultados) {
                        if (u.getDpi() != null && u.getDpi().trim().equals(dpiBuscado.trim())) {
                            encontrado = u;
                            break;
                        }
                    }
                    String respuesta;
                    if (encontrado == null) {
                        respuesta = "no_encontrado";
                    } else {
                        // Formato: "encontrado|nombre|apellido"
                        respuesta = "encontrado|" +
                            (encontrado.getNombre() == null ? "" : encontrado.getNombre()) + "|" +
                            (encontrado.getApellido() == null ? "" : encontrado.getApellido());
                    }
                    out.println(new MensajePC1(MensajePC1.RESULTADO_BUSQUEDA, respuesta).toWire());
                }
            }
        }

        private void entregarUsuario(UsuarioPC1 u, PrintWriter out) {
            if (u == null) {
                out.println(new MensajePC1(MensajePC1.COLA_VACIA, "No hay usuarios").toWire());
            } else {
                u.setEstado("EN_ATENCION");
                u.setHoraInicioAtencion(LocalDateTime.now());

                // Si el DPI ya tiene historial, copiar nombre y apellido
                List<UsuarioPC1> historial = arbolHistorial.buscar(u.getDpi());
                if (!historial.isEmpty()) {
                    UsuarioPC1 ultimo = historial.get(historial.size() - 1);
                    if (ultimo.getNombre() != null && !ultimo.getNombre().isEmpty()) {
                        u.setNombre(ultimo.getNombre());
                    }
                    if (ultimo.getApellido() != null && !ultimo.getApellido().isEmpty()) {
                        u.setApellido(ultimo.getApellido());
                    }
                    log("DPI conocido: " + u.getDpi() + " -> " + u.getNombre() + " " + u.getApellido());
                }

                enAtencion.put(u.getTicket(), u);
                out.println(new MensajePC1(MensajePC1.USUARIO_ASIGNADO, u).toWire());
                log("Asignado: " + u.getTicket() + " -> " + nombrePC);
            }
            actualizarGUI();
        }
    }

    // ══════════════════════════ CHAT GLOBAL ════════════════════════════
    /**
     * Envia un mensaje de chat a TODOS los clientes conectados y lo muestra
     * tambien en la ventana del servidor (chat tab y log).
     */
    private void difundirChat(String origen, String texto) {
        final String linea = "[" + java.time.LocalTime.now().format(
            java.time.format.DateTimeFormatter.ofPattern("HH:mm")) + "] " + origen + ": " + texto;

        // Mostrar en GUI del servidor (pestaña CHAT)
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                if (txtChat != null) {
                    txtChat.append(linea + "\n");
                    txtChat.setCaretPosition(txtChat.getDocument().getLength());
                }
                // Indicador visual: si no estamos en la pestaña CHAT, marcarla con *
                if (tabsDerecha != null) {
                    int idxChat = 1; // CHAT es el segundo tab
                    if (tabsDerecha.getSelectedIndex() != idxChat) {
                        tabsDerecha.setTitleAt(idxChat, "CHAT *");
                        tabsDerecha.setForegroundAt(idxChat, ESPECIAL);
                    }
                }
            }
        });

        // Tambien lo registramos en el log para que sea visible aunque
        // no este abierta la pestaña CHAT
        log("[CHAT] " + origen + ": " + texto);

        // Reenviar a todos los clientes conectados
        String wire = new MensajePC1(MensajePC1.CHAT, origen + "||" + texto).toWire();
        for (PrintWriter pw : clientes) {
            try { pw.println(wire); } catch (Exception ignored) {}
        }
    }

    private void actualizarListaPCs() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                modeloPCs.clear();
                modeloPCs.addElement("● PC1 - Servidor (este equipo)");
                for (String nombre : nombrePorCliente.values()) {
                    modeloPCs.addElement("● " + nombre);
                }
                lblConectados.setText("PCs: " + (1 + nombrePorCliente.size()));
            }
        });
    }

    // ══════════════════════════ LOGICA ═════════════════════════════════
    private String generarTicket(boolean prioritario) {
        String prefijo = prioritario ? "P" : "G";
        return prefijo + String.format("%03d", contadorTickets.getAndIncrement());
    }

    private void broadcast() {
        String estado = "G:" + colaGeneral.size() + "/P:" + colaPrioritaria.size() + "/E:" + colaEspecial.size();
        String linea = new MensajePC1(MensajePC1.BROADCAST_ESTADO, estado).toWire();
        for (PrintWriter out : clientes) {
            try { out.println(linea); } catch (Exception ignored) {}
        }
    }

    private void guardarCSV(UsuarioPC1 u) {
        try {
            File f = new File(ARCHIVO_CSV);
            boolean nuevo = !f.exists();
            FileWriter fw = new FileWriter(f, true);
            PrintWriter pw = new PrintWriter(fw);
            if (nuevo) pw.println(UsuarioPC1.csvHeader());
            pw.println(u.toCSV());
            pw.close();
        } catch (IOException e) { log("Error CSV: " + e.getMessage()); }
    }

    private void cargarHistorialCSV() {
        File f = new File(ARCHIVO_CSV);
        if (!f.exists()) return;
        try {
            BufferedReader br = new BufferedReader(new FileReader(f));
            String linea;
            boolean primera = true;
            boolean csvNuevo = true;   // formato con columna Precios
            int contador = 0;
            while ((linea = br.readLine()) != null) {
                if (primera) {
                    primera = false;
                    // Detectar version del CSV mirando el header
                    csvNuevo = linea.contains("Precios");
                    log("CSV " + (csvNuevo ? "nuevo" : "antiguo") + " detectado");
                    continue;
                }
                String[] cols = linea.split(",", -1);
                if (cols.length < 2) continue;

                try {
                    // Indices del CSV:
                    // FORMATO NUEVO (con Precios en col 9):
                    //   0: FechaHora    7: CantLamparas   14: HoraIngresoCola
                    //   1: DPI          8: Disenios       15: MotivoPrioritario
                    //   2: Nombre       9: Precios        16: Edad
                    //   3: Apellido    10: TotalQ         17: Discapacidad
                    //   4: Motivo      11: DurAtencion    18: MesesGestacion
                    //   5: Ticket      12: DurTotal
                    //   6: TipoAtencion 13: AtendidoPor
                    //
                    // FORMATO ANTIGUO (sin Precios): los indices 9-13 se corren -1
                    //   9: TotalQ      11: DurTotal       13: HoraIngresoCola
                    //  10: DurAtencion 12: AtendidoPor

                    int idxTotal      = csvNuevo ? 10 : 9;
                    int idxDurAtencion= csvNuevo ? 11 : 10;
                    int idxAtendidoPor= csvNuevo ? 13 : 12;
                    int idxHoraIngreso= csvNuevo ? 14 : 13;

                    boolean prior = cols.length > 6 && "PRIORITARIA".equalsIgnoreCase(cols[6]);
                    UsuarioPC1 u = new UsuarioPC1(cols[1], cols.length > 5 ? cols[5] : "", prior);

                    if (cols.length > 2) u.setNombre(cols[2]);
                    if (cols.length > 3) u.setApellido(cols[3]);
                    if (cols.length > 4) u.setMotivoAtencion(cols[4]);
                    if (cols.length > 6) u.setTipoAtencion(cols[6]);

                    // Cantidad de lamparas
                    if (cols.length > 7 && !cols[7].isEmpty()) {
                        try { u.setCantidadLamparas(Integer.parseInt(cols[7].trim())); }
                        catch (NumberFormatException ignored) {}
                    }
                    // Disenios (revertir el reemplazo "," por ";")
                    if (cols.length > 8) {
                        u.setDisenios(cols[8].replace(";", ","));
                    }
                    // Precios (solo en formato nuevo)
                    if (csvNuevo && cols.length > 9) {
                        u.setPrecios(cols[9].replace(";", ","));
                    }
                    // Total a pagar
                    if (cols.length > idxTotal && !cols[idxTotal].isEmpty()) {
                        try { u.setTotalPagar(Double.parseDouble(cols[idxTotal].trim())); }
                        catch (NumberFormatException ignored) {}
                    }
                    // Duracion de atencion en minutos
                    if (cols.length > idxDurAtencion && !cols[idxDurAtencion].isEmpty()) {
                        try {
                            long mins = Long.parseLong(cols[idxDurAtencion].trim());
                            u.setDuracionAtencionPersistida(mins);
                        } catch (NumberFormatException ignored) {}
                    }
                    // Usuario que atendio
                    if (cols.length > idxAtendidoPor) u.setUsuarioQueAtendio(cols[idxAtendidoPor]);

                    // Fechas
                    if (cols.length > 0 && !cols[0].isEmpty()) {
                        try { u.setHoraFinAtencion(java.time.LocalDateTime.parse(cols[0].trim(),
                            UsuarioPC1.FORMATTER)); }
                        catch (Exception ignored) {}
                    }
                    if (cols.length > idxHoraIngreso && !cols[idxHoraIngreso].isEmpty()) {
                        try { u.setHoraIngresoCola(java.time.LocalDateTime.parse(cols[idxHoraIngreso].trim(),
                            UsuarioPC1.FORMATTER)); }
                        catch (Exception ignored) {}
                    }
                    // Solo en formato nuevo: motivo prioritario y datos demograficos
                    if (csvNuevo) {
                        if (cols.length > 15) u.setMotivoPrioritario(cols[15]);
                        if (cols.length > 16 && !cols[16].isEmpty()) {
                            try { u.setEdad(Integer.parseInt(cols[16].trim())); } catch (Exception ignored) {}
                        }
                        if (cols.length > 17 && !cols[17].isEmpty()) {
                            u.setDiscapacidad("true".equalsIgnoreCase(cols[17].trim()));
                        }
                        if (cols.length > 18 && !cols[18].isEmpty()) {
                            try { u.setMesesGestacion(Integer.parseInt(cols[18].trim())); } catch (Exception ignored) {}
                        }
                    }

                    u.setEstado("ATENDIDO");
                    arbolHistorial.insertar(cols[1], u);
                    contador++;
                } catch (Exception e) {
                    log("Linea CSV invalida ignorada: " + e.getMessage());
                }
            }
            br.close();
            log("Historial cargado: " + contador + " atenciones restauradas en Arbol B+");
        } catch (IOException e) { log("No se pudo cargar historial: " + e.getMessage()); }
    }

    private void buscarPorDPI() {
        String dpi = txtBuscarDPI.getText().trim();
        if (dpi.isEmpty()) return;
        long inicio = System.nanoTime();
        List<UsuarioPC1> raw = arbolHistorial.buscar(dpi);
        long fin = System.nanoTime();
        long microSeg = (fin - inicio) / 1000;

        // Filtro de seguridad: solo coincidencias EXACTAS
        List<UsuarioPC1> resultados = new ArrayList<UsuarioPC1>();
        for (UsuarioPC1 u : raw) {
            if (u.getDpi() != null && u.getDpi().trim().equals(dpi)) {
                resultados.add(u);
            }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("===================================================\n");
        sb.append("  BUSQUEDA POR DPI: ").append(dpi).append("\n");
        sb.append("===================================================\n");
        sb.append("  Tiempo de busqueda: ").append(microSeg).append(" microsegundos\n");
        sb.append("  Complejidad:        O(log n)  [Arbol B+]\n");
        sb.append("  Registros total:    ").append(arbolHistorial.getTotalRegistros()).append("\n");
        sb.append("  Coincidencias:      ").append(resultados.size()).append("\n");
        sb.append("===================================================\n\n");

        if (resultados.isEmpty()) {
            sb.append("  >> Sin registros para este DPI.\n");
            sb.append("  >> Es la primera vez que se atiende a este cliente.\n");
        } else {
            // Datos generales del cliente (mismos en todas las atenciones)
            UsuarioPC1 primero = resultados.get(0);
            sb.append("--- DATOS DEL CLIENTE ---\n");
            sb.append("  DPI:       ").append(primero.getDpi()).append("\n");
            sb.append("  Nombre:    ").append(primero.getNombre()).append(" ").append(primero.getApellido()).append("\n");
            sb.append("  Atenciones registradas: ").append(resultados.size()).append("\n");

            // Acumulados de todas las atenciones
            int totalLamp = 0;
            int totalBasico = 0, totalTemporada = 0, totalPersonalizado = 0;
            double granTotal = 0.0;
            long minutosTotal = 0;
            for (UsuarioPC1 u : resultados) {
                totalLamp += u.getCantidadLamparas();
                granTotal += u.getTotalPagar();
                minutosTotal += u.getDuracionAtencionMinutos();
                String[] dis = (u.getDisenios() == null ? "" : u.getDisenios()).split(",");
                for (String d : dis) {
                    String t = d.trim().toUpperCase();
                    if (t.equals("BASICO")) totalBasico++;
                    else if (t.equals("TEMPORADA")) totalTemporada++;
                    else if (t.equals("PERSONALIZADO")) totalPersonalizado++;
                }
            }
            sb.append("  Lamparas total comprado: ").append(totalLamp).append("\n");
            sb.append("    Basicas:        ").append(totalBasico).append("\n");
            sb.append("    Temporada:      ").append(totalTemporada).append("\n");
            sb.append("    Personalizadas: ").append(totalPersonalizado).append("\n");
            sb.append("  Tiempo total atendido: ").append(minutosTotal).append(" min\n");
            sb.append("  Total gastado: Q ").append(String.format("%.2f", granTotal)).append("\n");
            sb.append("\n");

            // Detalle de cada atencion
            int i = 1;
            for (UsuarioPC1 u : resultados) {
                sb.append("--- Atencion #").append(i++).append(" ---\n");
                sb.append("  Ticket:        ").append(u.getTicket()).append("\n");
                sb.append("  Tipo:          ").append(u.getTipoAtencion()).append("\n");
                sb.append("  Atendido por:  ").append(u.getUsuarioQueAtendio()).append("\n");
                sb.append("  Motivo:        ").append(u.getMotivoAtencion()).append("\n");
                sb.append("  Lamparas:      ").append(u.getCantidadLamparas()).append("\n");

                // Desglose por tipo de diseno en esta atencion
                int basicos = 0, temp = 0, pers = 0;
                String[] dis = (u.getDisenios() == null ? "" : u.getDisenios()).split(",");
                for (String d : dis) {
                    String t = d.trim().toUpperCase();
                    if (t.equals("BASICO")) basicos++;
                    else if (t.equals("TEMPORADA")) temp++;
                    else if (t.equals("PERSONALIZADO")) pers++;
                }
                sb.append("    Basicas:        ").append(basicos).append("  (Q100 c/u)\n");
                sb.append("    Temporada:      ").append(temp).append("  (Q250 c/u)\n");
                sb.append("    Personalizadas: ").append(pers).append("  (Q400+ c/u)\n");
                sb.append("  Disenios:      ").append(u.getDisenios()).append("\n");
                sb.append("  Precios:       ").append(u.getPrecios()).append("\n");
                sb.append("  Tiempo atendido: ").append(u.getDuracionAtencionMinutos()).append(" min\n");
                sb.append("  TOTAL ATENCION: Q ").append(String.format("%.2f", u.getTotalPagar())).append("\n");
                sb.append("\n");
            }
        }
        txtResultadoBusqueda.setText(sb.toString());
        txtResultadoBusqueda.setCaretPosition(0);
    }

    private void mostrarHistorialCompleto() {
        long inicio = System.nanoTime();
        List<UsuarioPC1> todos = arbolHistorial.listarTodos();
        long fin = System.nanoTime();
        long microSeg = (fin - inicio) / 1000;

        Map<String, Integer> conteoPorDPI = new LinkedHashMap<String, Integer>();
        for (UsuarioPC1 u : todos) {
            String dpi = u.getDpi();
            Integer c = conteoPorDPI.get(dpi);
            conteoPorDPI.put(dpi, c == null ? 1 : c + 1);
        }

        // Acumulados globales
        int totalLamp = 0, totalBasico = 0, totalTemporada = 0, totalPersonalizado = 0;
        double granTotal = 0.0;
        long minutosTotal = 0;
        for (UsuarioPC1 u : todos) {
            totalLamp += u.getCantidadLamparas();
            granTotal += u.getTotalPagar();
            minutosTotal += u.getDuracionAtencionMinutos();
            String[] dis = (u.getDisenios() == null ? "" : u.getDisenios()).split(",");
            for (String d : dis) {
                String t = d.trim().toUpperCase();
                if (t.equals("BASICO")) totalBasico++;
                else if (t.equals("TEMPORADA")) totalTemporada++;
                else if (t.equals("PERSONALIZADO")) totalPersonalizado++;
            }
        }

        StringBuilder sb = new StringBuilder();
        sb.append("===================================================\n");
        sb.append("  HISTORIAL COMPLETO - LUMI 3D\n");
        sb.append("===================================================\n");
        sb.append("  Tiempo de recorrido: ").append(microSeg).append(" microsegundos\n");
        sb.append("  Complejidad:         O(n)  [recorrido hojas B+]\n");
        sb.append("  Total atenciones:    ").append(todos.size()).append("\n");
        sb.append("  DPIs unicos:         ").append(conteoPorDPI.size()).append("\n");
        sb.append("  Lamparas vendidas:   ").append(totalLamp).append("\n");
        sb.append("    Basicas:        ").append(totalBasico).append("\n");
        sb.append("    Temporada:      ").append(totalTemporada).append("\n");
        sb.append("    Personalizadas: ").append(totalPersonalizado).append("\n");
        sb.append("  Tiempo total atencion: ").append(minutosTotal).append(" min\n");
        sb.append("  Ingresos totales: Q ").append(String.format("%.2f", granTotal)).append("\n");
        sb.append("===================================================\n\n");

        if (todos.isEmpty()) {
            sb.append("  >> No hay registros en el historial.\n");
        } else {
            sb.append("--- DPIs REGISTRADOS ---\n\n");
            int i = 1;
            for (Map.Entry<String, Integer> entry : conteoPorDPI.entrySet()) {
                sb.append(String.format("  %2d. DPI: %s   (%d atencion%s)\n",
                    i++, entry.getKey(), entry.getValue(),
                    entry.getValue() == 1 ? "" : "es"));
            }

            sb.append("\n--- DETALLE DE TODAS LAS ATENCIONES ---\n\n");
            int j = 1;
            for (UsuarioPC1 u : todos) {
                int basicos = 0, temp = 0, pers = 0;
                String[] dis = (u.getDisenios() == null ? "" : u.getDisenios()).split(",");
                for (String d : dis) {
                    String t = d.trim().toUpperCase();
                    if (t.equals("BASICO")) basicos++;
                    else if (t.equals("TEMPORADA")) temp++;
                    else if (t.equals("PERSONALIZADO")) pers++;
                }

                sb.append("[").append(j++).append("] ");
                sb.append("DPI:").append(u.getDpi());
                sb.append(" | Ticket:").append(u.getTicket());
                sb.append(" | ").append(u.getNombre()).append(" ").append(u.getApellido()).append("\n");
                sb.append("    Tipo: ").append(u.getTipoAtencion());
                sb.append(" | Atendido por: ").append(u.getUsuarioQueAtendio());
                sb.append(" | Tiempo: ").append(u.getDuracionAtencionMinutos()).append(" min\n");
                sb.append("    Lamparas: ").append(u.getCantidadLamparas());
                sb.append("  (Bas:").append(basicos);
                sb.append(" Temp:").append(temp);
                sb.append(" Pers:").append(pers).append(")\n");
                sb.append("    Total: Q ").append(String.format("%.2f", u.getTotalPagar())).append("\n");
                sb.append("\n");
            }
        }
        txtResultadoBusqueda.setText(sb.toString());
        txtResultadoBusqueda.setCaretPosition(0);
    }

    private void actualizarGUI() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                // Separar usuarios EN_ATENCION por tipo de cola
                List<UsuarioPC1> enAtencionGen = new ArrayList<UsuarioPC1>();
                List<UsuarioPC1> enAtencionPrio = new ArrayList<UsuarioPC1>();
                List<UsuarioPC1> enAtencionEsp = new ArrayList<UsuarioPC1>();
                for (UsuarioPC1 u : enAtencion.values()) {
                    if (u.isPrioritario()) enAtencionPrio.add(u);
                    else if ("ESPECIAL".equals(u.getTipoAtencion())) enAtencionEsp.add(u);
                    else enAtencionGen.add(u);
                }

                // Combinar: primero los en atencion, luego la cola
                List<UsuarioPC1> listaGen = new ArrayList<UsuarioPC1>(enAtencionGen);
                listaGen.addAll(colaGeneral);
                List<UsuarioPC1> listaPrio = new ArrayList<UsuarioPC1>(enAtencionPrio);
                listaPrio.addAll(colaPrioritaria);
                List<UsuarioPC1> listaEsp = new ArrayList<UsuarioPC1>(enAtencionEsp);
                listaEsp.addAll(colaEspecial);

                actualizarTabla(modeloGeneral, listaGen);
                actualizarTabla(modeloPrioritario, listaPrio);
                actualizarTabla(modeloEspecial, listaEsp);

                // Los badges del header muestran el TOTAL (atendiendo + en cola)
                lblGeneral.setText("GENERAL: " + listaGen.size());
                lblPrioritario.setText("PRIORITARIO: " + listaPrio.size());
                lblEspecial.setText("ESPECIAL: " + listaEsp.size());
                lblTotal.setText("ATENDIDOS: " + arbolHistorial.getTotalRegistros());
            }
        });
    }

    private void actualizarTabla(DefaultTableModel modelo, List<UsuarioPC1> lista) {
        modelo.setRowCount(0);
        for (UsuarioPC1 u : lista) {
            String estado = u.getEstado();
            // Mostrar "ATENDIENDO" mas visible que "EN_ATENCION"
            if ("EN_ATENCION".equals(estado)) estado = "ATENDIENDO";

            String tiempo;
            if ("ATENDIENDO".equals(estado)) {
                // Tiempo desde que inicio la atencion
                long mins = u.getDuracionAtencionEnCursoMinutos();
                tiempo = mins > 0 ? mins + " min" : "< 1 min";
            } else {
                long espera = u.getDuracionEsperaMinutos();
                tiempo = espera > 0 ? espera + " min" : "< 1 min";
            }
            modelo.addRow(new Object[]{u.getTicket(), u.getDpi(), estado, tiempo});
        }
    }

    private void log(final String msg) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                txtLog.append("[" + java.time.LocalTime.now().format(
                    java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")) + "] " + msg + "\n");
                txtLog.setCaretPosition(txtLog.getDocument().getLength());
            }
        });
    }

    public static void main(String[] args) {
        Properties config = cargarConfig();
        final int puerto = Integer.parseInt(config.getProperty("server.port", "5000"));
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
                catch (Exception ignored) {}
                new Servidor(puerto);
            }
        });
    }

    static Properties cargarConfig() {
        Properties p = new Properties();
        try {
            FileInputStream fis = new FileInputStream("config.properties");
            p.load(fis);
            fis.close();
        } catch (IOException e) {
            p.setProperty("server.port", "5000");
            p.setProperty("server.ip", "localhost");
        }
        return p;
    }
}
