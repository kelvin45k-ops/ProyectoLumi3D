package pc1;

import java.util.*;

/**
 * Arbol B+ para busqueda eficiente por DPI.
 * Solo se usa en el servidor (PC1). Complejidad O(log n).
 */
public class BPlusTreePC1 {

    private final int orden;
    private Nodo raiz;
    private int totalRegistros;

    public BPlusTreePC1(int orden) {
        this.orden = orden;
        this.raiz = new NodoHoja();
        this.totalRegistros = 0;
    }

    private abstract class Nodo {
        List<String> claves;
        Nodo() { claves = new ArrayList<String>(); }
        abstract boolean esHoja();
        abstract List<UsuarioPC1> buscar(String clave);
        abstract ResultadoInsercion insertar(String clave, UsuarioPC1 valor);
    }

    private class NodoInterno extends Nodo {
        List<Nodo> hijos;
        NodoInterno() { super(); hijos = new ArrayList<Nodo>(); }
        boolean esHoja() { return false; }

        List<UsuarioPC1> buscar(String clave) {
            int i = 0;
            while (i < claves.size() && clave.compareTo(claves.get(i)) >= 0) i++;
            return hijos.get(i).buscar(clave);
        }

        ResultadoInsercion insertar(String clave, UsuarioPC1 valor) {
            int i = 0;
            while (i < claves.size() && clave.compareTo(claves.get(i)) >= 0) i++;
            ResultadoInsercion res = hijos.get(i).insertar(clave, valor);
            if (res == null) return null;
            claves.add(i, res.claveSube);
            hijos.add(i + 1, res.nodoDerecho);
            if (claves.size() >= orden) return dividirInterno();
            return null;
        }

        private ResultadoInsercion dividirInterno() {
            int mitad = claves.size() / 2;
            String claveSube = claves.get(mitad);
            NodoInterno derecho = new NodoInterno();
            derecho.claves = new ArrayList<String>(claves.subList(mitad + 1, claves.size()));
            derecho.hijos  = new ArrayList<Nodo>(hijos.subList(mitad + 1, hijos.size()));
            claves = new ArrayList<String>(claves.subList(0, mitad));
            hijos  = new ArrayList<Nodo>(hijos.subList(0, mitad + 1));
            return new ResultadoInsercion(claveSube, derecho);
        }
    }

    private class NodoHoja extends Nodo {
        List<List<UsuarioPC1>> valores;
        NodoHoja siguiente;

        NodoHoja() { super(); valores = new ArrayList<List<UsuarioPC1>>(); siguiente = null; }
        boolean esHoja() { return true; }

        List<UsuarioPC1> buscar(String clave) {
            // Busqueda EXACTA: solo devuelve resultados donde el DPI coincide al 100%
            for (int i = 0; i < claves.size(); i++) {
                String claveNodo = claves.get(i);
                if (claveNodo != null && claveNodo.equals(clave)) {
                    return new ArrayList<UsuarioPC1>(valores.get(i));
                }
            }
            return new ArrayList<UsuarioPC1>();
        }

        ResultadoInsercion insertar(String clave, UsuarioPC1 valor) {
            int i = 0;
            while (i < claves.size() && clave.compareTo(claves.get(i)) > 0) i++;
            if (i < claves.size() && claves.get(i).equals(clave)) {
                valores.get(i).add(valor);
            } else {
                claves.add(i, clave);
                List<UsuarioPC1> lista = new ArrayList<UsuarioPC1>();
                lista.add(valor);
                valores.add(i, lista);
            }
            if (claves.size() >= orden) return dividirHoja();
            return null;
        }

        private ResultadoInsercion dividirHoja() {
            int mitad = claves.size() / 2;
            NodoHoja derecho = new NodoHoja();
            derecho.claves = new ArrayList<String>(claves.subList(mitad, claves.size()));
            derecho.valores= new ArrayList<List<UsuarioPC1>>(valores.subList(mitad, valores.size()));
            derecho.siguiente = this.siguiente;
            this.claves  = new ArrayList<String>(claves.subList(0, mitad));
            this.valores = new ArrayList<List<UsuarioPC1>>(valores.subList(0, mitad));
            this.siguiente = derecho;
            return new ResultadoInsercion(derecho.claves.get(0), derecho);
        }
    }

    private static class ResultadoInsercion {
        String claveSube;
        Nodo nodoDerecho;
        ResultadoInsercion(String cs, Nodo nd) { claveSube = cs; nodoDerecho = nd; }
    }

    public synchronized void insertar(String dpi, UsuarioPC1 usuario) {
        if (dpi == null) return;
        String clave = dpi.trim();
        ResultadoInsercion res = raiz.insertar(clave, usuario);
        totalRegistros++;
        if (res != null) {
            NodoInterno nuevaRaiz = new NodoInterno();
            nuevaRaiz.claves.add(res.claveSube);
            nuevaRaiz.hijos.add(raiz);
            nuevaRaiz.hijos.add(res.nodoDerecho);
            raiz = nuevaRaiz;
        }
    }

    public synchronized List<UsuarioPC1> buscar(String dpi) {
        if (dpi == null) return new ArrayList<UsuarioPC1>();
        return raiz.buscar(dpi.trim());
    }

    public int getTotalRegistros() { return totalRegistros; }

    /**
     * Recorre todas las hojas enlazadas (caracteristica del Arbol B+)
     * Devuelve TODOS los registros en orden ascendente por DPI.
     * Complejidad: O(n)
     */
    public synchronized List<UsuarioPC1> listarTodos() {
        List<UsuarioPC1> resultado = new ArrayList<UsuarioPC1>();
        // Bajar al primer NodoHoja del extremo izquierdo
        Nodo actual = raiz;
        while (!actual.esHoja()) {
            actual = ((NodoInterno) actual).hijos.get(0);
        }
        // Recorrer hojas enlazadas
        NodoHoja hoja = (NodoHoja) actual;
        while (hoja != null) {
            for (List<UsuarioPC1> lista : hoja.valores) {
                resultado.addAll(lista);
            }
            hoja = hoja.siguiente;
        }
        return resultado;
    }

    /**
     * Devuelve solo los DPIs unicos (sin duplicados) en orden
     */
    public synchronized List<String> listarDPIsUnicos() {
        List<String> resultado = new ArrayList<String>();
        Nodo actual = raiz;
        while (!actual.esHoja()) {
            actual = ((NodoInterno) actual).hijos.get(0);
        }
        NodoHoja hoja = (NodoHoja) actual;
        while (hoja != null) {
            for (String clave : hoja.claves) {
                resultado.add(clave);
            }
            hoja = hoja.siguiente;
        }
        return resultado;
    }
}
