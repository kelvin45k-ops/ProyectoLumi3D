package pc3;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class UsuarioPC3 implements Serializable, Comparable<UsuarioPC3> {
    private static final long serialVersionUID = 1L;

    private String dpi;
    private String nombre;
    private String apellido;
    private String ticket;
    private boolean prioritario;
    private String motivoAtencion;
    private String usuarioQueAtendio;
    private LocalDateTime horaIngresoCola;
    private LocalDateTime horaInicioAtencion;
    private LocalDateTime horaFinAtencion;
    private String estado;
    private String tipoAtencion;
    private int prioridad;

    // ─── Datos Lumi 3D ───
    private int cantidadLamparas = 1;
    private int edad;                  // si es adulto mayor
    private boolean discapacidad;      // si tiene discapacidad
    private int mesesGestacion;        // si es embarazada
    private String motivoPrioritario;  // "MAYOR" | "DISCAPACIDAD" | "EMBARAZADA"
    private String disenios = "";      // ej: "BASICO,TEMPORADA,PERSONALIZADO"
    private String precios = "";       // ej: "100.0,250.0,425.5"
    private double totalPagar;

    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    public UsuarioPC3() {
        // Constructor vacio para fromWire
    }

    public UsuarioPC3(String dpi, String ticket, boolean prioritario) {
        this.dpi = dpi;
        this.ticket = ticket;
        this.prioritario = prioritario;
        this.horaIngresoCola = LocalDateTime.now();
        this.estado = "ESPERANDO";
        this.prioridad = prioritario ? 1 : 5;
        this.tipoAtencion = prioritario ? "PRIORITARIA" : "GENERAL";
    }

    @Override
    public int compareTo(UsuarioPC3 otro) {
        return Integer.compare(this.prioridad, otro.prioridad);
    }

    // ══════════════════════════ WIRE PROTOCOL ══════════════════════════
    // Serializa a una linea de texto con campos separados por |
    // Formato: dpi=XXX|ticket=YYY|prioritario=true|...
    // Asi los 5 PCs pueden intercambiar datos aunque cada uno tenga su propia clase

    public String toWire() {
        StringBuilder sb = new StringBuilder();
        sb.append("dpi=").append(safe(dpi));
        sb.append("|ticket=").append(safe(ticket));
        sb.append("|prioritario=").append(prioritario);
        sb.append("|tipoAtencion=").append(safe(tipoAtencion));
        sb.append("|nombre=").append(safe(nombre));
        sb.append("|apellido=").append(safe(apellido));
        sb.append("|motivo=").append(safe(motivoAtencion));
        sb.append("|agente=").append(safe(usuarioQueAtendio));
        sb.append("|horaIngreso=").append(horaIngresoCola != null ? horaIngresoCola.toString() : "");
        sb.append("|horaInicio=").append(horaInicioAtencion != null ? horaInicioAtencion.toString() : "");
        sb.append("|horaFin=").append(horaFinAtencion != null ? horaFinAtencion.toString() : "");
        sb.append("|estado=").append(safe(estado));
        sb.append("|prioridad=").append(prioridad);
        sb.append("|cantidadLamparas=").append(cantidadLamparas);
        sb.append("|edad=").append(edad);
        sb.append("|discapacidad=").append(discapacidad);
        sb.append("|mesesGestacion=").append(mesesGestacion);
        sb.append("|motivoPrior=").append(safe(motivoPrioritario));
        sb.append("|disenios=").append(safe(disenios));
        sb.append("|precios=").append(safe(precios));
        sb.append("|totalPagar=").append(totalPagar);
        return sb.toString();
    }

    public static UsuarioPC3 fromWire(String wire) {
        UsuarioPC3 u = new UsuarioPC3();
        if (wire == null || wire.isEmpty()) return u;
        String[] parts = wire.split("\\|");
        for (String part : parts) {
            int eq = part.indexOf('=');
            if (eq < 0) continue;
            String key = part.substring(0, eq);
            String val = part.substring(eq + 1);
            try {
                if (key.equals("dpi"))             u.dpi = val;
                else if (key.equals("ticket"))     u.ticket = val;
                else if (key.equals("prioritario"))u.prioritario = Boolean.parseBoolean(val);
                else if (key.equals("tipoAtencion"))u.tipoAtencion = val;
                else if (key.equals("nombre"))     u.nombre = val;
                else if (key.equals("apellido"))   u.apellido = val;
                else if (key.equals("motivo"))     u.motivoAtencion = val;
                else if (key.equals("agente"))     u.usuarioQueAtendio = val;
                else if (key.equals("horaIngreso") && !val.isEmpty()) u.horaIngresoCola = LocalDateTime.parse(val);
                else if (key.equals("horaInicio") && !val.isEmpty())  u.horaInicioAtencion = LocalDateTime.parse(val);
                else if (key.equals("horaFin") && !val.isEmpty())     u.horaFinAtencion = LocalDateTime.parse(val);
                else if (key.equals("estado"))     u.estado = val;
                else if (key.equals("prioridad")) u.prioridad = Integer.parseInt(val);
                else if (key.equals("cantidadLamparas")) u.cantidadLamparas = Integer.parseInt(val);
                else if (key.equals("edad")) u.edad = Integer.parseInt(val);
                else if (key.equals("discapacidad")) u.discapacidad = Boolean.parseBoolean(val);
                else if (key.equals("mesesGestacion")) u.mesesGestacion = Integer.parseInt(val);
                else if (key.equals("motivoPrior")) u.motivoPrioritario = val;
                else if (key.equals("disenios")) u.disenios = val;
                else if (key.equals("precios")) u.precios = val;
                else if (key.equals("totalPagar")) u.totalPagar = Double.parseDouble(val);
            } catch (Exception ignored) {}
        }
        return u;
    }

    private static String safe(String s) {
        if (s == null) return "";
        return s.replace("|", "/").replace("=", ":").replace("\n", " ").replace("\r", " ");
    }

    // ══════════════════════════ CALCULOS ════════════════════════════════
    public long getDuracionEsperaMinutos() {
        if (horaInicioAtencion == null || horaIngresoCola == null) return 0;
        return java.time.Duration.between(horaIngresoCola, horaInicioAtencion).toMinutes();
    }

    public long getDuracionAtencionMinutos() {
        if (horaInicioAtencion == null || horaFinAtencion == null) return 0;
        return java.time.Duration.between(horaInicioAtencion, horaFinAtencion).toMinutes();
    }

    public long getDuracionTotalMinutos() {
        if (horaIngresoCola == null || horaFinAtencion == null) return 0;
        return java.time.Duration.between(horaIngresoCola, horaFinAtencion).toMinutes();
    }

    public String toCSV() {
        return String.join(",",
            horaFinAtencion != null ? horaFinAtencion.format(FORMATTER) : "",
            dpi != null ? dpi : "",
            nombre != null ? nombre : "",
            apellido != null ? apellido : "",
            motivoAtencion != null ? motivoAtencion : "",
            ticket != null ? ticket : "",
            tipoAtencion != null ? tipoAtencion : "",
            String.valueOf(cantidadLamparas),
            disenios != null ? disenios.replace(",", ";") : "",
            String.format("%.2f", totalPagar),
            String.valueOf(getDuracionAtencionMinutos()),
            String.valueOf(getDuracionTotalMinutos()),
            usuarioQueAtendio != null ? usuarioQueAtendio : "",
            horaIngresoCola != null ? horaIngresoCola.format(FORMATTER) : ""
        );
    }

    public static String csvHeader() {
        return "FechaHora,DPI,Nombre,Apellido,Motivo,Ticket,TipoAtencion,CantLamparas,Disenios,TotalQ,DuracionAtencion(min),DuracionTotal(min),AtendidoPor,HoraIngresoCola";
    }

    // ══════════════════════════ GETTERS/SETTERS ═════════════════════════
    public String getDpi() { return dpi; }
    public void setDpi(String dpi) { this.dpi = dpi; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }
    public String getTicket() { return ticket; }
    public void setTicket(String ticket) { this.ticket = ticket; }
    public boolean isPrioritario() { return prioritario; }
    public void setPrioritario(boolean prioritario) { this.prioritario = prioritario; }
    public String getMotivoAtencion() { return motivoAtencion; }
    public void setMotivoAtencion(String motivoAtencion) { this.motivoAtencion = motivoAtencion; }
    public String getUsuarioQueAtendio() { return usuarioQueAtendio; }
    public void setUsuarioQueAtendio(String usuarioQueAtendio) { this.usuarioQueAtendio = usuarioQueAtendio; }
    public LocalDateTime getHoraIngresoCola() { return horaIngresoCola; }
    public void setHoraIngresoCola(LocalDateTime horaIngresoCola) { this.horaIngresoCola = horaIngresoCola; }
    public LocalDateTime getHoraInicioAtencion() { return horaInicioAtencion; }
    public void setHoraInicioAtencion(LocalDateTime horaInicioAtencion) { this.horaInicioAtencion = horaInicioAtencion; }
    public LocalDateTime getHoraFinAtencion() { return horaFinAtencion; }
    public void setHoraFinAtencion(LocalDateTime horaFinAtencion) { this.horaFinAtencion = horaFinAtencion; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public String getTipoAtencion() { return tipoAtencion; }
    public void setTipoAtencion(String tipoAtencion) { this.tipoAtencion = tipoAtencion; }
    public int getPrioridad() { return prioridad; }
    public void setPrioridad(int prioridad) { this.prioridad = prioridad; }

    // ─── Getters/Setters Lumi 3D ───
    public int getCantidadLamparas() { return cantidadLamparas; }
    public void setCantidadLamparas(int c) { this.cantidadLamparas = c; }
    public int getEdad() { return edad; }
    public void setEdad(int e) { this.edad = e; }
    public boolean isDiscapacidad() { return discapacidad; }
    public void setDiscapacidad(boolean d) { this.discapacidad = d; }
    public int getMesesGestacion() { return mesesGestacion; }
    public void setMesesGestacion(int m) { this.mesesGestacion = m; }
    public String getMotivoPrioritario() { return motivoPrioritario; }
    public void setMotivoPrioritario(String m) { this.motivoPrioritario = m; }
    public String getDisenios() { return disenios; }
    public void setDisenios(String d) { this.disenios = d; }
    public String getPrecios() { return precios; }
    public void setPrecios(String p) { this.precios = p; }
    public double getTotalPagar() { return totalPagar; }
    public void setTotalPagar(double t) { this.totalPagar = t; }

    @Override
    public String toString() {
        return "[" + ticket + "] DPI:" + dpi + " | " + estado +
               (nombre != null ? " | " + nombre + " " + apellido : "");
    }
}
