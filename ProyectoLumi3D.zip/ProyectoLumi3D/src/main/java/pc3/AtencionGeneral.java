package pc3;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class AtencionGeneral extends JFrame {

    protected Socket socket;
    protected PrintWriter out;
    protected BufferedReader in;
    protected ChatPanel chatPanel;
    protected final BlockingQueue<MensajePC3> colaRespuestas = new LinkedBlockingQueue<MensajePC3>();

    protected static final int TIPO_GENERAL     = 1;
    protected static final int TIPO_PRIORITARIO = 2;
    protected static final int TIPO_ESPECIAL    = 3;

    private final AtomicBoolean atencionActiva = new AtomicBoolean(false);
    private volatile UsuarioPC3 usuarioActual = null;
    private final String tipoAtencionStr;
    private final int tipoSolicitud;
    private javax.swing.Timer cronometro;
    private LocalDateTime horaInicioAtencion;

    protected JLabel lblTicket, lblDPI, lblEstado, lblConexion, lblCronometro, lblTotal;
    protected JTextField txtNombre, txtApellido, txtMotivo, txtUsuarioAgente;
    protected JButton btnSiguiente, btnFinalizar;
    protected JTextArea txtHistorial;
    protected JPanel panelLamparas;
    protected JScrollPane scrollLamparas;
    protected java.util.List<FilaLampara> filasLamparas = new ArrayList<FilaLampara>();

    // ──────── PALETA LUMI 3D - TEMA CLARO ────────
    protected static final Color BG          = new Color(210, 210, 210);  // gris ceniza
    protected static final Color CARD        = new Color(255, 255, 255);  // tarjetas blancas
    protected static final Color CARD2       = new Color(238, 238, 238);  // alt
    protected static final Color BORDER      = new Color(181, 181, 181);  // bordes
    protected final Color ACCENT;
    protected static final Color ACCENT_GOLD = new Color(201, 162, 39);   // dorado Lumi
    protected static final Color GOLD_DARK   = new Color(168, 130, 30);   // dorado oscuro
    protected static final Color OK          = new Color(95, 170, 95);    // verde
    protected static final Color DANGER      = new Color(200, 80, 80);    // rojo
    protected static final Color TEXT        = new Color(44, 44, 44);     // texto
    protected static final Color TEXT_DIM    = new Color(102, 102, 102);  // secundario

    public AtencionGeneral(String titulo, String tipoAtencion, int tipoSolicitud, Color accentColor) {
        this.tipoAtencionStr = tipoAtencion;
        this.tipoSolicitud = tipoSolicitud;
        this.ACCENT = accentColor;
        initGUI(titulo);
        conectar();
        setVisible(true);
    }

    private void initGUI(String titulo) {
        setTitle("Lumi 3D  -  " + titulo);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 820);
        setMinimumSize(new Dimension(980, 720));
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout(10, 10));
        add(crearHeader(titulo), BorderLayout.NORTH);
        add(crearCentro(), BorderLayout.CENTER);
        add(crearFooter(), BorderLayout.SOUTH);
    }

    private JPanel crearHeader(String titulo) {
        JPanel p = new JPanel(new BorderLayout(15, 0));
        p.setBackground(CARD);
        p.setBorder(new CompoundBorder(
            new MatteBorder(0, 0, 2, 0, ACCENT_GOLD),
            new EmptyBorder(12, 22, 12, 22)));

        // Lado izquierdo: logo grafico + titulo en dos lineas
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        left.setOpaque(false);
        left.add(new LogoLumi3D(54, false));

        JPanel titulos = new JPanel();
        titulos.setLayout(new BoxLayout(titulos, BoxLayout.Y_AXIS));
        titulos.setOpaque(false);
        JLabel tMain = new JLabel("Lumi 3D");
        tMain.setFont(new Font("Segoe UI", Font.BOLD, 22));
        tMain.setForeground(ACCENT_GOLD);
        JLabel tSub = new JLabel(titulo);
        tSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tSub.setForeground(ACCENT);
        titulos.add(tMain);
        titulos.add(tSub);
        left.add(titulos);

        // Lado derecho: chat + estado
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);
        JButton btnChat = new JButton("CHAT");
        btnChat.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btnChat.setBackground(ACCENT);
        btnChat.setForeground(Color.WHITE);
        btnChat.setBorder(new EmptyBorder(6, 16, 6, 16));
        btnChat.setFocusPainted(false);
        btnChat.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnChat.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (chatPanel != null) chatPanel.setVisible(true);
            }
        });
        lblConexion = new JLabel("DESCONECTADO");
        lblConexion.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblConexion.setForeground(DANGER);
        right.add(btnChat);
        right.add(lblConexion);

        p.add(left, BorderLayout.WEST);
        p.add(right, BorderLayout.EAST);
        return p;
    }

    private JPanel crearCentro() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(0, 12, 0, 12));
        p.add(crearPanelTicket(), BorderLayout.WEST);
        p.add(crearPanelFormulario(), BorderLayout.CENTER);
        return p;
    }

    private JPanel crearPanelTicket() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setPreferredSize(new Dimension(280, 0));
        p.setBackground(CARD);
        p.setBorder(new CompoundBorder(new LineBorder(ACCENT, 1), new EmptyBorder(16, 16, 16, 16)));

        JLabel lblT = new JLabel("TICKET");
        lblT.setFont(new Font("Consolas", Font.BOLD, 11));
        lblT.setForeground(TEXT_DIM);
        lblT.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(lblT);
        lblTicket = new JLabel("-");
        lblTicket.setFont(new Font("Consolas", Font.BOLD, 36));
        lblTicket.setForeground(ACCENT);
        lblTicket.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(lblTicket);
        p.add(Box.createVerticalStrut(14));

        JLabel lblD = new JLabel("DPI");
        lblD.setFont(new Font("Consolas", Font.BOLD, 11));
        lblD.setForeground(TEXT_DIM);
        lblD.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(lblD);
        lblDPI = new JLabel("-");
        lblDPI.setFont(new Font("Consolas", Font.PLAIN, 16));
        lblDPI.setForeground(TEXT);
        lblDPI.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(lblDPI);
        p.add(Box.createVerticalStrut(20));

        JLabel lblC = new JLabel("TIEMPO EN ATENCION");
        lblC.setFont(new Font("Consolas", Font.BOLD, 10));
        lblC.setForeground(TEXT_DIM);
        lblC.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(lblC);
        lblCronometro = new JLabel("00:00:00");
        lblCronometro.setFont(new Font("Consolas", Font.BOLD, 32));
        lblCronometro.setForeground(ACCENT);
        lblCronometro.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(lblCronometro);
        p.add(Box.createVerticalStrut(16));

        lblEstado = new JLabel("LISTO PARA ATENDER");
        lblEstado.setFont(new Font("Consolas", Font.BOLD, 12));
        lblEstado.setForeground(OK);
        lblEstado.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(lblEstado);
        p.add(Box.createVerticalStrut(20));

        btnSiguiente = botonGrande("LLAMAR SIGUIENTE", ACCENT);
        btnSiguiente.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { llamarSiguiente(); }
        });
        p.add(btnSiguiente);
        p.add(Box.createVerticalStrut(8));

        btnFinalizar = botonGrande("FINALIZAR ATENCION", DANGER);
        btnFinalizar.setEnabled(false);
        btnFinalizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) { finalizarAtencion(); }
        });
        p.add(btnFinalizar);
        p.add(Box.createVerticalGlue());
        return p;
    }

    private JPanel crearPanelFormulario() {
        JPanel p = new JPanel(new BorderLayout(0, 10));
        p.setOpaque(false);

        JPanel datos = new JPanel();
        datos.setLayout(new BoxLayout(datos, BoxLayout.Y_AXIS));
        datos.setBackground(CARD);
        datos.setBorder(new CompoundBorder(new LineBorder(CARD2, 1), new EmptyBorder(12, 14, 12, 14)));

        JLabel lblD = new JLabel("DATOS DE ATENCION");
        lblD.setFont(new Font("Consolas", Font.BOLD, 12));
        lblD.setForeground(ACCENT);
        lblD.setAlignmentX(Component.LEFT_ALIGNMENT);
        datos.add(lblD);
        datos.add(Box.createVerticalStrut(8));

        txtNombre = inputField();
        datos.add(labeled("NOMBRE", txtNombre));
        txtApellido = inputField();
        datos.add(labeled("APELLIDO", txtApellido));
        txtMotivo = inputField();
        datos.add(labeled("MOTIVO DE ATENCION", txtMotivo));
        txtUsuarioAgente = inputField();
        datos.add(labeled("AGENTE QUE ATIENDE", txtUsuarioAgente));

        JPanel lamparasContainer = new JPanel(new BorderLayout(0, 6));
        lamparasContainer.setBackground(CARD);
        lamparasContainer.setBorder(new CompoundBorder(new LineBorder(CARD2, 1), new EmptyBorder(12, 14, 12, 14)));

        JPanel lamparasHeader = new JPanel(new BorderLayout());
        lamparasHeader.setOpaque(false);
        JLabel lblL = new JLabel("LAMPARAS A IMPRIMIR  (Lumi 3D)");
        lblL.setFont(new Font("Consolas", Font.BOLD, 12));
        lblL.setForeground(ACCENT_GOLD);
        lamparasHeader.add(lblL, BorderLayout.WEST);
        lblTotal = new JLabel("TOTAL: Q 0.00");
        lblTotal.setFont(new Font("Consolas", Font.BOLD, 16));
        lblTotal.setForeground(OK);
        lamparasHeader.add(lblTotal, BorderLayout.EAST);
        lamparasContainer.add(lamparasHeader, BorderLayout.NORTH);

        panelLamparas = new JPanel();
        panelLamparas.setLayout(new BoxLayout(panelLamparas, BoxLayout.Y_AXIS));
        panelLamparas.setBackground(CARD);

        scrollLamparas = new JScrollPane(panelLamparas);
        scrollLamparas.setBorder(null);
        scrollLamparas.getViewport().setBackground(CARD);
        scrollLamparas.setPreferredSize(new Dimension(0, 300));
        scrollLamparas.getVerticalScrollBar().setUnitIncrement(16);
        lamparasContainer.add(scrollLamparas, BorderLayout.CENTER);

        p.add(datos, BorderLayout.NORTH);
        p.add(lamparasContainer, BorderLayout.CENTER);
        return p;
    }

    private JPanel crearFooter() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(CARD2);
        p.setBorder(new EmptyBorder(8, 12, 8, 12));
        JLabel lbl = new JLabel("HISTORIAL DE ATENCIONES");
        lbl.setFont(new Font("Consolas", Font.BOLD, 11));
        lbl.setForeground(ACCENT);
        txtHistorial = new JTextArea(4, 60);
        txtHistorial.setFont(new Font("Consolas", Font.PLAIN, 10));
        txtHistorial.setBackground(BG);
        txtHistorial.setForeground(TEXT_DIM);
        txtHistorial.setEditable(false);
        JScrollPane sc = new JScrollPane(txtHistorial);
        sc.setBorder(null);
        p.add(lbl, BorderLayout.NORTH);
        p.add(sc, BorderLayout.CENTER);
        return p;
    }

    private JTextField inputField() {
        JTextField t = new JTextField();
        t.setFont(new Font("Consolas", Font.PLAIN, 13));
        t.setBackground(BG);
        t.setForeground(TEXT);
        t.setCaretColor(ACCENT);
        t.setBorder(new CompoundBorder(new LineBorder(CARD2, 1), new EmptyBorder(6, 8, 6, 8)));
        t.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        t.setAlignmentX(Component.LEFT_ALIGNMENT);
        return t;
    }

    private Component labeled(String label, JComponent input) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        p.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel l = new JLabel(label);
        l.setFont(new Font("Consolas", Font.BOLD, 9));
        l.setForeground(TEXT_DIM);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        l.setBorder(new EmptyBorder(2, 0, 2, 0));
        p.add(l);
        p.add(input);
        p.add(Box.createVerticalStrut(4));
        return p;
    }

    private JButton botonGrande(String texto, Color color) {
        JButton b = new JButton(texto);
        b.setFont(new Font("Consolas", Font.BOLD, 13));
        b.setForeground(color);
        b.setBackground(BG);
        b.setBorder(new CompoundBorder(new LineBorder(color, 2), new EmptyBorder(10, 0, 10, 0)));
        b.setFocusPainted(false);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    /** Una fila por lampara: tipo de diseno + precio (editable solo en personalizado) */
    class FilaLampara extends JPanel {
        JComboBox<String> cbDiseno;
        JSpinner spnPrecio;
        JLabel lblNum;

        FilaLampara(int numero) {
            setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
            setBackground(CARD2);
            setBorder(new CompoundBorder(new LineBorder(CARD, 1), new EmptyBorder(8, 10, 8, 10)));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
            setAlignmentX(Component.LEFT_ALIGNMENT);

            lblNum = new JLabel("#" + numero);
            lblNum.setFont(new Font("Consolas", Font.BOLD, 13));
            lblNum.setForeground(ACCENT_GOLD);
            lblNum.setPreferredSize(new Dimension(40, 28));
            add(lblNum);
            add(Box.createHorizontalStrut(8));

            cbDiseno = new JComboBox<String>(new String[]{
                "Basico (Q100)", "Temporada (Q250)", "Personalizado (Q400+)"
            });
            cbDiseno.setFont(new Font("Consolas", Font.PLAIN, 12));
            cbDiseno.setMaximumSize(new Dimension(220, 30));
            cbDiseno.setPreferredSize(new Dimension(220, 30));
            add(cbDiseno);
            add(Box.createHorizontalStrut(8));

            JLabel lblQ = new JLabel("Q");
            lblQ.setFont(new Font("Consolas", Font.BOLD, 14));
            lblQ.setForeground(TEXT_DIM);
            add(lblQ);
            add(Box.createHorizontalStrut(4));

            spnPrecio = new JSpinner(new SpinnerNumberModel(100.0, 100.0, 9999.0, 25.0));
            spnPrecio.setFont(new Font("Consolas", Font.BOLD, 13));
            spnPrecio.setMaximumSize(new Dimension(110, 30));
            spnPrecio.setPreferredSize(new Dimension(110, 30));
            spnPrecio.setEnabled(false);
            add(spnPrecio);

            cbDiseno.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    int idx = cbDiseno.getSelectedIndex();
                    if (idx == 0) { spnPrecio.setValue(100.0); spnPrecio.setEnabled(false); }
                    else if (idx == 1) { spnPrecio.setValue(250.0); spnPrecio.setEnabled(false); }
                    else { spnPrecio.setValue(400.0); spnPrecio.setEnabled(true); }
                    actualizarTotal();
                }
            });
            spnPrecio.addChangeListener(new javax.swing.event.ChangeListener() {
                public void stateChanged(javax.swing.event.ChangeEvent e) { actualizarTotal(); }
            });
            cbDiseno.setSelectedIndex(0);
        }

        String getTipoDiseno() {
            int idx = cbDiseno.getSelectedIndex();
            if (idx == 0) return "BASICO";
            if (idx == 1) return "TEMPORADA";
            return "PERSONALIZADO";
        }

        double getPrecio() { return (Double) spnPrecio.getValue(); }
    }

    private void generarFilasLamparas(int n) {
        panelLamparas.removeAll();
        filasLamparas.clear();
        for (int i = 1; i <= n; i++) {
            FilaLampara fl = new FilaLampara(i);
            filasLamparas.add(fl);
            panelLamparas.add(fl);
            panelLamparas.add(Box.createVerticalStrut(4));
        }
        panelLamparas.revalidate();
        panelLamparas.repaint();
        actualizarTotal();
    }

    private void actualizarTotal() {
        double total = 0;
        for (FilaLampara fl : filasLamparas) total += fl.getPrecio();
        DecimalFormat df = new DecimalFormat("0.00");
        lblTotal.setText("TOTAL: Q " + df.format(total));
    }

    // ══════════════════════════ ATENCION ════════════════════════════════
    private void llamarSiguiente() {
        if (atencionActiva.get()) {
            JOptionPane.showMessageDialog(this,
                "Hay una atencion en curso. Finalicela primero.",
                "Recurso Bloqueado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (out == null) {
            JOptionPane.showMessageDialog(this, "No hay conexion al servidor.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        new Thread(new Runnable() {
            public void run() {
                try {
                    String tipoMsg = MensajePC3.SOLICITAR_SIGUIENTE_GENERAL;
                    if (tipoSolicitud == TIPO_PRIORITARIO)      tipoMsg = MensajePC3.SOLICITAR_SIGUIENTE_PRIORITARIO;
                    else if (tipoSolicitud == TIPO_ESPECIAL)    tipoMsg = MensajePC3.SOLICITAR_SIGUIENTE_ESPECIAL;

                    synchronized (out) {
                        out.println(new MensajePC3(tipoMsg, "").toWire());
                    }

                    final MensajePC3 resp = colaRespuestas.poll(5, TimeUnit.SECONDS);
                    if (resp == null) return;

                    if (MensajePC3.USUARIO_ASIGNADO.equals(resp.getTipo())) {
                        usuarioActual = resp.getUsuario();
                        horaInicioAtencion = LocalDateTime.now();
                        atencionActiva.set(true);
                        SwingUtilities.invokeLater(new Runnable() {
                            public void run() { mostrarUsuario(usuarioActual); }
                        });
                        iniciarCronometro();
                    } else if (MensajePC3.COLA_VACIA.equals(resp.getTipo())) {
                        SwingUtilities.invokeLater(new Runnable() {
                            public void run() {
                                JOptionPane.showMessageDialog(AtencionGeneral.this,
                                    "No hay usuarios en la cola.",
                                    "Cola vacia", JOptionPane.INFORMATION_MESSAGE);
                            }
                        });
                    }
                } catch (Exception e) {}
            }
        }, "Thread-SiguienteUsuario").start();
    }

    private void finalizarAtencion() {
        if (usuarioActual == null) return;
        if (txtNombre.getText().trim().isEmpty() || txtApellido.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nombre y apellido son obligatorios.", "Validacion", JOptionPane.WARNING_MESSAGE);
            return;
        }

        StringBuilder dis = new StringBuilder();
        StringBuilder pre = new StringBuilder();
        double total = 0;
        for (int i = 0; i < filasLamparas.size(); i++) {
            FilaLampara fl = filasLamparas.get(i);
            if (i > 0) { dis.append(";"); pre.append(";"); }
            dis.append(fl.getTipoDiseno());
            pre.append(String.format(Locale.US, "%.2f", fl.getPrecio()));
            total += fl.getPrecio();
        }

        usuarioActual.setNombre(txtNombre.getText().trim());
        usuarioActual.setApellido(txtApellido.getText().trim());
        usuarioActual.setMotivoAtencion(txtMotivo.getText().trim());
        usuarioActual.setUsuarioQueAtendio(txtUsuarioAgente.getText().trim());
        usuarioActual.setHoraFinAtencion(LocalDateTime.now());
        usuarioActual.setEstado("ATENDIDO");
        usuarioActual.setDisenios(dis.toString());
        usuarioActual.setPrecios(pre.toString());
        usuarioActual.setTotalPagar(total);

        try {
            synchronized (out) {
                out.println(new MensajePC3(MensajePC3.FINALIZAR_ATENCION, usuarioActual).toWire());
            }
        } catch (Exception e) {}

        DecimalFormat df = new DecimalFormat("0.00");
        log("Finalizado: " + usuarioActual.getTicket() + " - " + usuarioActual.getNombre() +
            " - Total Q" + df.format(total));

        try { if (cronometro != null) cronometro.stop(); }
        finally {
            atencionActiva.set(false);
            SwingUtilities.invokeLater(new Runnable() {
                public void run() { limpiarFormulario(); }
            });
        }
    }

    private void mostrarUsuario(UsuarioPC3 u) {
        lblTicket.setText(u.getTicket());
        lblDPI.setText(u.getDpi());
        lblEstado.setText("EN ATENCION");
        lblEstado.setForeground(ACCENT);
        setFormHabilitado(true);
        txtNombre.setText(u.getNombre() != null ? u.getNombre() : "");
        txtApellido.setText(u.getApellido() != null ? u.getApellido() : "");
        txtMotivo.setText("");
        txtUsuarioAgente.setText("");

        int cant = u.getCantidadLamparas() > 0 ? u.getCantidadLamparas() : 1;
        generarFilasLamparas(cant);

        btnSiguiente.setEnabled(false);
        btnFinalizar.setEnabled(true);
    }

    private void limpiarFormulario() {
        lblTicket.setText("-");
        lblDPI.setText("-");
        lblEstado.setText("LISTO PARA ATENDER");
        lblEstado.setForeground(OK);
        lblCronometro.setText("00:00:00");
        txtNombre.setText("");
        txtApellido.setText("");
        txtMotivo.setText("");
        txtUsuarioAgente.setText("");
        panelLamparas.removeAll();
        filasLamparas.clear();
        panelLamparas.revalidate();
        panelLamparas.repaint();
        lblTotal.setText("TOTAL: Q 0.00");
        usuarioActual = null;
        setFormHabilitado(false);
        btnSiguiente.setEnabled(true);
        btnFinalizar.setEnabled(false);
    }

    private void setFormHabilitado(boolean h) {
        txtNombre.setEnabled(h);
        txtApellido.setEnabled(h);
        txtMotivo.setEnabled(h);
        txtUsuarioAgente.setEnabled(h);
    }

    private void iniciarCronometro() {
        if (cronometro != null) cronometro.stop();
        cronometro = new javax.swing.Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (horaInicioAtencion == null) return;
                long seg = java.time.Duration.between(horaInicioAtencion, LocalDateTime.now()).getSeconds();
                long h = seg / 3600, m = (seg % 3600) / 60, s = seg % 60;
                lblCronometro.setText(String.format("%02d:%02d:%02d", h, m, s));
            }
        });
        cronometro.start();
    }

    // ══════════════════════════ CONEXION ═══════════════════════════════
    protected void conectar() {
        new Thread(new Runnable() {
            public void run() {
                Properties config = cargarConfig();
                String ip = config.getProperty("server.ip", "localhost");
                int puerto = Integer.parseInt(config.getProperty("server.port", "5000"));
                int timeout = Integer.parseInt(config.getProperty("client.timeout.ms", "2000"));

                String pcName = "PC3-General";
                if (tipoSolicitud == TIPO_PRIORITARIO) pcName = "PC4-Prioritaria";
                else if (tipoSolicitud == TIPO_ESPECIAL) pcName = "PC5-Especial";

                int intento = 0;
                // Reintentar INFINITAMENTE hasta conectar
                while (true) {
                    intento++;
                    try {
                        if (intento == 1) {
                            actualizarEstadoConexion("CONECTANDO...", new Color(255, 180, 50));
                        } else {
                            actualizarEstadoConexion("RECONECTANDO (intento " + intento + ")", DANGER);
                        }
                        socket = new Socket();
                        socket.connect(new java.net.InetSocketAddress(ip, puerto), timeout);
                        out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);
                        in  = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));

                        actualizarEstadoConexion("CONECTADO", OK);
                        log("Conectado al servidor (intento " + intento + ").");

                        synchronized (out) {
                            out.println(new MensajePC3(MensajePC3.IDENTIFICAR, pcName).toWire());
                        }
                        if (chatPanel == null) {
                            final String pn = pcName;
                            SwingUtilities.invokeLater(new Runnable() {
                                public void run() { chatPanel = new ChatPanel(pn, out); }
                            });
                        } else {
                            // Actualizar el PrintWriter del chat tras reconectar
                            chatPanel.actualizarOut(out);
                        }

                        new Thread(new Runnable() {
                            public void run() { hiloLector(); }
                        }, "Thread-Lector").start();
                        return;
                    } catch (IOException e) {
                        log("Intento " + intento + ": " + e.getMessage());
                        try { Thread.sleep(timeout); } catch (InterruptedException ignored) {}
                    }
                }
            }
        }, "Thread-Conexion").start();
    }

    private void actualizarEstadoConexion(final String texto, final Color color) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                lblConexion.setText(texto);
                lblConexion.setForeground(color);
            }
        });
    }

    private void hiloLector() {
        try {
            String linea;
            while ((linea = in.readLine()) != null) {
                MensajePC3 m = MensajePC3.fromWire(linea);
                String tipo = m.getTipo();
                if (MensajePC3.USUARIO_ASIGNADO.equals(tipo) ||
                    MensajePC3.COLA_VACIA.equals(tipo) ||
                    MensajePC3.CONFIRMACION.equals(tipo) ||
                    MensajePC3.ERROR.equals(tipo)) {
                    colaRespuestas.put(m);
                } else if (MensajePC3.CHAT.equals(tipo)) {
                    if (chatPanel != null) chatPanel.recibirMensaje(m.getDatos());
                } else if (MensajePC3.BROADCAST_ESTADO.equals(tipo)) {
                    log("Colas: " + m.getDatos());
                }
            }
            // readLine devolvio null = servidor cerro la conexion
            manejarDesconexion("Servidor cerro la conexion");
        } catch (Exception e) {
            manejarDesconexion("Error de lectura: " + e.getMessage());
        }
    }

    /**
     * Cuando se pierde la conexion: avisa al usuario y reconecta automaticamente
     */
    private void manejarDesconexion(String motivo) {
        log("DESCONEXION: " + motivo);
        actualizarEstadoConexion("DESCONECTADO  -  Reconectando...", DANGER);
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JOptionPane.showMessageDialog(
                    AtencionGeneral.this,
                    "Conexion fallida con el servidor.\n\nReconectando automaticamente...",
                    "Servidor desconectado",
                    JOptionPane.WARNING_MESSAGE);
            }
        });
        // Cerrar socket actual
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        // Volver a conectar (esto reintenta infinito)
        conectar();
    }

    private void log(final String msg) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                txtHistorial.append("[" + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) +
                                    "] " + msg + "\n");
                txtHistorial.setCaretPosition(txtHistorial.getDocument().getLength());
            }
        });
    }

    static Properties cargarConfig() {
        Properties p = new Properties();
        try {
            FileInputStream fis = new FileInputStream("config.properties");
            p.load(fis);
            fis.close();
        } catch (IOException e) {
            p.setProperty("server.ip", "localhost");
            p.setProperty("server.port", "5000");
            p.setProperty("client.reconnect.attempts", "5");
            p.setProperty("client.timeout.ms", "2000");
        }
        return p;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
                catch (Exception ignored) {}
                new AtencionGeneral(
                    "PC3 - ATENCION GENERAL",
                    "GENERAL",
                    TIPO_GENERAL,
                    new Color(120, 160, 200));  // azul mate Lumi
            }
        });
    }
}
